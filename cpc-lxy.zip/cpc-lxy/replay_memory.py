import pickle
import os
import random
import numpy as np
import torch
import kornia

class ReplayMemory:
    def __init__(self, capacity, seed, obs_shape, action_shape, args):
        random.seed(seed)
        self.capacity = capacity
        obs_shape = [obs_shape[2], obs_shape[0], obs_shape[1]]
        self.obses = np.empty((capacity, *obs_shape), dtype=np.float32)
        self.next_obses = np.empty((capacity, *obs_shape), dtype=np.float32)
        self.actions = np.empty((capacity, *action_shape), dtype=np.float32)
        self.rewards = np.empty((capacity, 1), dtype=np.float32)
        self.dones = np.empty((capacity, 1), dtype=np.float32)
        self.idx = 0
        self.full = False
        self.device = torch.device("cuda" if args.cuda else "cpu")

    def push(self, obs, action, reward, next_obs, done):
        np.copyto(self.obses[self.idx], obs)
        np.copyto(self.actions[self.idx], action)
        np.copyto(self.rewards[self.idx], reward)
        np.copyto(self.next_obses[self.idx], next_obs)
        np.copyto(self.dones[self.idx], done)
        self.idx = (self.idx + 1) % self.capacity
        self.full = self.full or self.idx == 0

    def sample(self, batch_size):
        idxs = np.random.randint(0, self.capacity if self.full else self.idx, size=batch_size)
        obses = self.obses[idxs]
        next_obses = self.next_obses[idxs]
        obses = torch.as_tensor(obses, device=self.device).float()
        next_obses = torch.as_tensor(next_obses, device=self.device).float()
        actions = torch.as_tensor(self.actions[idxs], device=self.device)
        rewards = torch.as_tensor(self.rewards[idxs], device=self.device)
        dones = torch.as_tensor(self.dones[idxs], device=self.device)
        return obses, actions, rewards, next_obses, dones

    def __len__(self):
        return len(self.buffer)

    def save_buffer(self, env_name, suffix="", save_path=None):
        if not os.path.exists('checkpoints/'):
            os.makedirs('checkpoints/')

        if save_path is None:
            save_path = "checkpoints/sac_buffer_{}_{}".format(env_name, suffix)
        print('Saving buffer to {}'.format(save_path))

        with open(save_path, 'wb') as f:
            pickle.dump(self.buffer, f)

    def load_buffer(self, save_path):
        print('Loading buffer from {}'.format(save_path))

        with open(save_path, "rb") as f:
            self.buffer = pickle.load(f)
            self.position = len(self.buffer) % self.capacity

class GoalReplayMemory:
    def __init__(self, capacity, seed, obs_shape, action_shape, args):
        random.seed(seed)
        self.capacity = capacity
        self.max_steps = args.max_steps
        self.episodes = int(capacity/args.max_steps)
        self.capacity = self.episodes * self.max_steps
        self.horizon = args.horizon
        obs_shape = [obs_shape[2], obs_shape[0], obs_shape[1]]
        np_capacity = [self.episodes, self.max_steps]
        self.obses = np.empty((*np_capacity, *obs_shape), dtype=np.float32)
        self.next_obses = np.empty((*np_capacity, *obs_shape), dtype=np.float32)
        self.actions = np.empty((*np_capacity, *action_shape), dtype=np.float32)
        self.rewards = np.empty((*np_capacity, 1), dtype=np.float32)
        self.dones = np.empty((*np_capacity, 1), dtype=np.float32)
        self.distances = np.empty((*np_capacity, 1), dtype=np.float32)
        self.idx = 0
        self.ep_idx = 0
        self.gamma = args.gamma
        self.obs_dim = int(obs_shape[0]/2)
        self.relabel_next_prob = args.relabel_next_prob
        self.relabel_future_prob = args.relabel_future_prob
        self.relabel_next_num = int(self.relabel_next_prob * args.batch_size)
        self.relabel_future_num = int(self.relabel_future_prob * args.batch_size)
        self.relabel_random_num = args.batch_size - (self.relabel_next_num + self.relabel_future_num)
        self.max_future_steps = np.ones(self.relabel_future_num) * self.max_steps
        self.crop = kornia.augmentation.RandomCrop((obs_shape[1], obs_shape[2]))

        self.full = False
        self.device = torch.device("cuda" if args.cuda else "cpu")

    def push(self, obs, action, reward, next_obs, done, distance):
        np.copyto(self.obses[self.ep_idx, self.idx], obs)
        np.copyto(self.actions[self.ep_idx, self.idx], action)
        np.copyto(self.rewards[self.ep_idx, self.idx], reward)
        np.copyto(self.next_obses[self.ep_idx, self.idx], next_obs)
        np.copyto(self.dones[self.ep_idx, self.idx], done)
        np.copyto(self.distances[self.ep_idx, self.idx], distance)
        self.idx = (self.idx + 1) % self.max_steps
        if self.idx == 0:
            self.ep_idx = (self.ep_idx + 1) % self.episodes
            self.full = self.full or self.ep_idx == 0

    def sample(self, batch_size):
        idxs = np.random.randint(0, self.capacity if self.full else self.idx+self.max_steps*self.ep_idx, size=batch_size)
        ep_idx = (idxs/self.max_steps).astype(int)
        step_idx = (idxs%self.max_steps).astype(int)
        # idxs = np.concatenate([np.expand_dims(ep_idx, -1), np.expand_dims(step_idx, -1)], axis=-1)
        obses, next_obses, new_goals, old_goals = self.relabel(ep_idx, step_idx, batch_size) 
        actions = torch.as_tensor(self.actions[ep_idx, step_idx, ...], device=self.device)
        # rewards = torch.as_tensor(self.rewards[ep_idx, step_idx, ...], device=self.device)
        if self.relabel_random_num > 0:
            rewards = (next_obses[:, :self.obs_dim, :, :] == next_obses[:, self.obs_dim:, :, :]).float().prod(-1).prod(-1).prod(-1).unsqueeze(-1)
        else:
            rewards = None
        # dones = torch.as_tensor(self.dones[ep_idx, step_idx, ...], device=self.device)
        dones = None
        # obses = torch.concat([self.crop(obses[:, :self.obs_dim]), self.crop(obses[:, self.obs_dim:])], dim=1)
        # next_obses = torch.concat([self.crop(next_obses[:, :self.obs_dim]), self.crop(next_obses[:, self.obs_dim:])], dim=1)
        return obses, actions, rewards, next_obses, dones, old_goals

    def __len__(self):
        return len(self.buffer)

    def save_buffer(self, env_name, suffix="", save_path=None):
        if not os.path.exists('checkpoints/'):
            os.makedirs('checkpoints/')

        if save_path is None:
            save_path = "checkpoints/sac_buffer_{}_{}".format(env_name, suffix)
        print('Saving buffer to {}'.format(save_path))

        with open(save_path, 'wb') as f:
            pickle.dump({'obs': self.obses, 'next_obs': self.next_obses, 'act': self.actions, 'dist': self.distances}, f, protocol=4)
        # np.save(save_path, {'obs': self.obses, 'next_obs': self.next_obses, 'act': self.actions, 'dist': self.distances})

    def load_buffer(self, save_path):
        print('Loading buffer from {}'.format(save_path))

        with open(save_path, "rb") as f:
            self.buffer = pickle.load(f)
            self.position = len(self.buffer) % self.capacity

    def relabel(self, ep_idx, step_idx, batch_size):        
        obses = self.obses[ep_idx, step_idx, ...]
        next_obses = self.next_obses[ep_idx, step_idx, ...]
        old_goals = torch.as_tensor(obses[:, self.obs_dim:], device=self.device).float()
        if self.relabel_next_num > 0:
            next_goals = next_obses[:self.relabel_next_num, :self.obs_dim, :, :]
            next_goals = torch.as_tensor(next_goals, device=self.device).float()
        # future_step_idx = np.random.randint(step_idx[self.relabel_next_num:self.relabel_next_num+self.relabel_future_num], self.max_future_steps)
        future_idxs = torch.arange(self.max_steps, device=self.device).repeat(self.relabel_future_num, 1)
        future_start_idxs = torch.as_tensor(step_idx[self.relabel_next_num:self.relabel_next_num+self.relabel_future_num], device=self.device) 
        probs = self.gamma ** future_idxs * (future_idxs > future_start_idxs.unsqueeze(-1)).float() * \
                (future_idxs <= (future_start_idxs.unsqueeze(-1)+self.horizon)).float()
        # probs = (probs + (torch.sum(probs, dim=-1, keepdims=True) == 0).float()) / (torch.sum(probs, dim=-1, keepdims=True) + (torch.sum(probs, dim=-1, keepdims=True) == 0).float())
        probs = probs + (torch.sum(probs, dim=-1, keepdims=True) == 0).float()
        future_step_idx = torch.multinomial(probs, 1).squeeze().cpu().numpy()
        future_goals = self.obses[ep_idx[self.relabel_next_num:self.relabel_next_num+self.relabel_future_num], future_step_idx, ...][:, :self.obs_dim, :, :]
        # random_idxs = np.arange(self.relabel_random_num)
        # np.random.shuffle(random_idxs)
        # random_goals = obses[:self.relabel_random_num][random_idxs, ...][:, :self.obs_dim, :, :]
        if self.relabel_random_num > 0:
            random_goals = obses[:, :self.obs_dim, :, :]
            np.random.shuffle(random_goals)
            random_goals = random_goals[:self.relabel_random_num]
            random_goals = torch.as_tensor(random_goals, device=self.device).float()

 
        future_goals = torch.as_tensor(future_goals, device=self.device).float()
        if self.relabel_random_num > 0:
            if self.relabel_next_num > 0:
                new_goals = torch.concat([next_goals, future_goals, random_goals], dim=0)
            else:
                new_goals = torch.concat([future_goals, random_goals], dim=0)
        else:
            new_goals = future_goals
        obses = torch.as_tensor(obses, device=self.device).float()
        next_obses = torch.as_tensor(next_obses, device=self.device).float()
        obses = torch.concat([obses[:, :self.obs_dim, :, :], new_goals], dim=1)
        next_obses = torch.concat([next_obses[:, :self.obs_dim, :, :], new_goals], dim=1)
        return obses, next_obses, new_goals, old_goals

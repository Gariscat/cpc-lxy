import argparse
import datetime
import gym
import numpy as np
import itertools
import torch
from cpc import CPC
from cpc_aug import CPC_AUG
from cpc_spec import CPC_Spec
from clearning import CLearning
from torch.utils.tensorboard import SummaryWriter
from replay_memory import ReplayMemory, GoalReplayMemory
from wrappers import SawyerWrapper
import time
import kornia

parser = argparse.ArgumentParser(description='PyTorch Soft Actor-Critic Args')
parser.add_argument('--env_name', default="HalfCheetah-v2",
                    help='Mujoco Gym environment (default: HalfCheetah-v2)')
parser.add_argument('--agent_name', default="cpc",
                    help='Which agent to use (default: CPC)')
parser.add_argument('--policy', default="Gaussian",
                    help='Policy Type: Gaussian | Deterministic (default: Gaussian)')
parser.add_argument('--eval', type=bool, default=True,
                    help='Evaluates a policy a policy every 10 episode (default: True)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--tau', type=float, default=0.005, metavar='G',
                    help='target smoothing coefficient(τ) (default: 0.005)')
parser.add_argument('--lr', type=float, default=1e-4, metavar='G',
                    help='learning rate (default: 0.0003)')
parser.add_argument('--alpha', type=float, default=0.2, metavar='G',
                    help='Temperature parameter α determines the relative importance of the entropy\
                            term against the reward (default: 0.2)')
parser.add_argument('--entropy_reg', type=float, default=1e-4,
                    help='Entropy regularization for policy update')
parser.add_argument('--comment', type=str, default="",
                    help='run on CUDA (default: False)')
parser.add_argument('--automatic_entropy_tuning', type=bool, default=False, metavar='G',
                    help='Automaically adjust α (default: False)')
parser.add_argument('--seed', type=int, default=123456, metavar='N',
                    help='random seed (default: 123456)')
parser.add_argument('--max_steps', type=int, default=100, metavar='N',
                    help='maximum number of steps (default: 100)')
parser.add_argument('--horizon', type=int, default=50, metavar='N',
                    help='horizon of number steps (default: 50)')
parser.add_argument('--relabel_next_prob', type=float, default=0.0, metavar='G',
                    help='probability of relabeling next state (default: 0.0)')
parser.add_argument('--relabel_future_prob', type=float, default=0.5, metavar='G',
                    help='probability of relabeling future state (default: 0.5)')
parser.add_argument('--batch_size', type=int, default=256, metavar='N',
                    help='batch size (default: 256)')
parser.add_argument('--num_steps', type=int, default=1000001, metavar='N',
                    help='maximum number of steps (default: 1000000)')
parser.add_argument('--hidden_size', type=int, default=1024, metavar='N',
                    help='hidden size (default: 1024)')
parser.add_argument('--updates_per_step', type=int, default=1, metavar='N',
                    help='model updates per simulator step (default: 1)')
parser.add_argument('--steps_per_update', type=int, default=1, metavar='N',
                    help='env steps per update (default: 1)')
parser.add_argument('--start_steps', type=int, default=10000, metavar='N',
                    help='Steps sampling random actions (default: 10000)')
parser.add_argument('--target_update_interval', type=int, default=1, metavar='N',
                    help='Value target update per no. of updates per step (default: 1)')
parser.add_argument('--replay_size', type=int, default=100000, metavar='N',
                    help='size of replay buffer (default: 100000)')
parser.add_argument('--Ng', type=int, default=2, metavar='N',
                    help='size of Ng (default 2)')
parser.add_argument('--cuda', action="store_false",
                    help='run on CUDA (default: False)')
parser.add_argument('--share_encoder', action="store_true",
                    help='share encoder or not (default : false)')
parser.add_argument('--planning', action="store_true",
                    help='Perform planning or not (default : false)')
parser.add_argument('--eval_interval', type=int, default=9000, metavar='N',
                    help='number of steps to evaluate (default: 4000)')
args = parser.parse_args()

print(args)
# Environment
# env = NormalizedActions(gym.make(args.env_name))
# env = gym.make(args.env_name)
if 'sawyer' not in args.env_name and 'point' not in args.env_name:
    import dmc2gym
    domain_name = args.env_name.split("_")[0]
    task_name = "_".join(args.env_name.split("_")[1:])
    camera_id = 2 if domain_name == "quadruped" else 0
    env = dmc2gym.make(
        domain_name=domain_name,
        task_name=task_name,
        seed=args.seed,
        visualize_reward=False,
        from_pixels=True,
        height=48,
        width=48,
        frame_skip=4,
        camera_id=camera_id,
    )
    in_channel = env.observation_space.shape[0]
elif 'point' in args.env_name:
    from maze_env import *
    # env = PointEnvGoal(walls='SixRooms')
    walls = args.env_name[6:].capitalize()
    print(walls)
    env = PointEnvGoal(walls=walls)
    eval_env = PointEnvGoal(walls=walls)
    in_channel = env.observation_space.shape[2]
else:
    import cpc_envs
    # from multiworld.envs.mujoco import register_custom_envs as register_mujoco_envs
    # register_mujoco_envs()
    # env = gym.make('Image48SawyerPushAndReachArenaTrainEnvBig-v0')
    # env = SawyerWrapper(env)
    env = cpc_envs.load(args.env_name)
    eval_env = cpc_envs.load(args.env_name)
    in_channel = env.observation_space.shape[2]
env.seed(args.seed)
env.action_space.seed(args.seed)

# torch.manual_seed(args.seed)
# np.random.seed(args.seed)

# Agent
if args.agent_name == 'cpc':
    agent = CPC(in_channel, env.action_space, args)
elif args.agent_name == 'cpc_aug':
    agent = CPC_AUG(in_channel, env.action_space, args)
elif args.agent_name == 'clearning':
    agent = CLearning(in_channel, env.action_space, args)
elif args.agent_name == 'cpc_spec':
    agent = CPC_Spec(in_channel, env.action_space, args)

#Tesnorboard
writer = SummaryWriter('runs/{}_SAC_{}_{}_{}'.format(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"), args.env_name,
                                                             args.policy, "autotune" if args.automatic_entropy_tuning else ""))

writer.add_text('metadata', str(args), 0)

# Memory
memory = GoalReplayMemory(args.replay_size, args.seed, env.observation_space.shape, env.action_space.shape, args)
# memory = ReplayMemory(args.replay_size, args.seed, env.observation_space.shape, env.action_space.shape, args)

"""
def get_video(env, agent, max_steps, save_dir, cur_step):
    from moviepy.editor import ImageSequenceClip
    renders = []
    renders1 = []
    '''
    env.env.env._wrapped_env._get_viewer('rgb_array')
    env.env.viewer.cam.azimuth = 270
    env.env.viewer.cam.distance = 1.5
    env.env.viewer.cam.lookat[2] = -0.2
    '''
    # env.env._wrapped_env._get_viewer('rgb_array')
    # env.viewer.cam.azimuth = 270
    # env.viewer.cam.distance = 1.5
    # env.viewer.cam.lookat[2] = -0.2
    # env.viewer.cam.azimuth = 180
    # env.viewer.cam.distance = 1.2

    episode_steps = 0
    state = env.reset()
    for i in range(max_steps):
        # renders.append(np.transpose(np.array(env.env._wrapped_env.get_image(imsize=48)[:, :, :3]), (1, 0, 2)))
        # renders1.append(np.transpose(np.array((env.env.env._img_goal*255).reshape(48, 48, 5)[:, :, :3]), (1, 0, 2)))
        # renders1.append(np.flip(np.array((env.env._img_goal*255).reshape(64, 64, 3)[:, :, :3]), (0, 1)))
        renders1.append(np.flip(np.array((env.env.env._img_goal*255).reshape(64, 64, 3)[:, :, :3]), (0, 1)))
        # renders1.append(np.flip(np.array((env.env.env._img_goal*255).reshape(84, 84, 3)[:, :, :3]), (0, 1)))
        # renders1.append(np.flip(np.array((env.env._img_goal*255).reshape(64, 64, 5)[:, :, :3]), (0, 1)))
        # renders.append(np.transpose(np.array((state*255).reshape(6, 64, 64)[:3, :, :]), (2, 1, 0)))
        # crop = kornia.augmentation.RandomCrop((100, 100))
        # renders.append(np.flip(np.array(env.render(mode='rgb_array')), (0, 1)))
        img = np.flip(np.array(env.render(mode='rgb_array')), (0, 1))
        # r, g, b = img[:, :, 0], img[:, :, 1], img[:, :, 2]
        # gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
        # img = np.expand_dims(np.dot(img[...,:3], [0.299, 0.587, 0.114]), axis=-1)
        renders.append(img)
        # renders.append(np.transpose(np.array(crop(torch.tensor(np.transpose(np.array(env.render(mode='rgb_array')), (2, 0, 1))).float()).squeeze()), (1, 2, 0)))
        # print(state.reshape(10, 48, 48)[3, 0, 0], state.reshape(10, 48, 48)[4, 0, 0])

        action = agent.select_action(state, evaluate=True)
        next_state, _, _, _ = env.step(action)
        state = next_state
    clip = ImageSequenceClip(renders, fps=5)
    clip1 = ImageSequenceClip(renders1, fps=5)
    clip.write_gif(save_dir+'/render'+str(cur_step)+'.gif', fps=5)
    clip1.write_gif(save_dir+'/1render'+str(cur_step)+'.gif', fps=5)

"""

# Training Loop
train_total_numsteps = 0
eval_total_numsteps = 0
total_numsteps = 0
updates = 0
start_time = time.time()
# env.render(mode='rgb_array')
# eval_env.render(mode='rgb_array')
# get_video(eval_env, agent, args.max_steps, './', 0)

for i_episode in itertools.count(1):
    episode_reward = 0
    episode_steps = 0
    done = False
    state = env.reset()
    
    ## NOTE : Training
    
    ng = 0
    while not done:
        # print("TOTAL NUMSTEP", total_numsteps)
        if args.start_steps > total_numsteps:
            action = env.action_space.sample()  # Sample random action
        else:
            if args.planning and ng < args.Ng:
                # pass
                ng += 1
                # print(state.shape)
                state = agent.cplanning(memory, args.batch_size, state) 
                # print(state.shape)
            action = agent.select_action(state)  # Sample action from policy

        # if len(memory) > args.batch_size:
        if total_numsteps > args.start_steps and total_numsteps % args.steps_per_update == 0:
            # Number of updates per step in environment
            # save_sample = memory.sample(batch_size=1)
            # save_sample = np.transpose(sample.cpu().numpy().squeeze()[:3], (1, 2, 0))
            sample = None
            # for i in range(args.updates_per_step):
            if total_numsteps % 1 == 0:
                i = 0
                # Update parameters of all the networks
                critic_1_loss, critic_2_loss, policy_loss, ent_loss, alpha = agent.update_parameters(memory, args.batch_size, updates, sample, i)

                writer.add_scalar('loss/critic_1', critic_1_loss, updates)
                writer.add_scalar('loss/critic_2', critic_2_loss, updates)
                writer.add_scalar('loss/policy', policy_loss, updates)
                writer.add_scalar('loss/entropy_loss', ent_loss, updates)
                writer.add_scalar('entropy_temprature/alpha', alpha, updates)
                updates += 1

        # agent.obs_rms.update(state[:int(in_channel/2)])
        next_state, reward, done, info = env.step(action) # Step
        episode_steps += 1
        total_numsteps += 1
        eval_total_numsteps += 1
        train_total_numsteps += 1
        episode_reward += reward

        # Ignore the "done" signal if it comes from hitting the time horizon.
        # (https://github.com/openai/spinningup/blob/master/spinup/algos/sac/sac.py)
        # mask = 1 if episode_steps == args.max_steps else float(not done)
        if episode_steps == args.max_steps:
            done = True
        mask = float(not done)

        # import sys
        # np.set_printoptions(threshold=sys.maxsize)
        # print(next_state[:3] - state[:3])
        memory.push(state, action, reward, next_state, mask, info['state_distance']) # Append transition to memory

        '''
        if episode_steps == args.max_steps:
            obs_rms_states = memory.obses[(memory.ep_idx - 1) % memory.episodes]
            agent.obs_rms.update(obs_rms_states[:, :int(in_channel/2)])
        '''

        state = next_state

    if total_numsteps > args.num_steps:
        break

    writer.add_scalar('reward/train', episode_reward, i_episode)
    # if total_numsteps > args.start_steps and train_total_numsteps > 500:
    if train_total_numsteps > 2000 and total_numsteps > args.start_steps:
        end_time = time.time()
        fps = train_total_numsteps / (end_time - start_time)
        print("Episode: {}, fps: {}, total numsteps: {}, episode steps: {}, actor loss: {}, critic loss: {}".format(i_episode, round(fps, 2), total_numsteps, episode_steps, round(policy_loss, 2), round(critic_1_loss+critic_2_loss, 2)))
        start_time = time.time()
        train_total_numsteps = 0

    # TODO: changes 
    '''
    if total_numsteps % 100000 == 0:
        print('Save Buffer')
        memory.save_buffer(args.env_name)
        agent.save_checkpoint(args.env_name)
    '''
    ## NOTE : Testing
    if total_numsteps > args.start_steps and eval_total_numsteps > args.eval_interval and args.eval is True:
        avg_reward = 0.
        avg_dist = 0.
        episodes = 10
        avg_critic = 0.
        eval_steps = 0
        for _  in range(episodes):
            eval_state = eval_env.reset()
            episode_reward = 0
            episode_steps = 0
            done = False
            min_dist = 1e8
            while not done:
                action = agent.select_action(eval_state, evaluate=True)
                # q1, q2 = agent.critic(agent.norm_state(state), torch.FloatTensor(action).to(agent.device).unsqueeze(0))
                # avg_critic += (q1.detach().cpu().item() + q2.detach().cpu().item())/2

                eval_next_state, reward, done, info = eval_env.step(action)
                episode_reward += reward
                episode_steps += 1
                if info['state_distance'] < min_dist:
                    min_dist = info['state_distance']
                if episode_steps == args.max_steps:
                    done = True

                eval_state = eval_next_state
            avg_reward += episode_reward
            avg_dist += min_dist
            eval_steps += episode_steps
        avg_reward /= episodes
        avg_dist /= episodes
        avg_critic /= eval_steps
        eval_total_numsteps = 0

        writer.add_scalar('avg_reward/test', avg_dist, i_episode)

        print("----------------------------------------")
        print("Test Episodes: {}, Avg. Reward: {}, Min. Dist {}, Avg. q {}".format(episodes, round(avg_reward, 2), round(avg_dist, 2), round(avg_critic, 2)))
        print("----------------------------------------")
        # get_video(eval_env, agent, args.max_steps, './', total_numsteps)

env.close()


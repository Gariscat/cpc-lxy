import gym
import numpy as np
from collections import deque

class SawyerWrapper(gym.Wrapper):
    def __init__(self, env, distance_threshold=0.05):
        super().__init__(env)
        self.env = env
        self.action_space = self.env.action_space
        self.observation_space = self.env.observation_space
        self.distance_threshold = distance_threshold

    def reset(self):
        next_state = self.env.reset()
        obs = np.concatenate([next_state['image_observation'].reshape(self.env.imsize, self.env.imsize, -1),
            next_state['image_desired_goal'].reshape(self.env.imsize, self.env.imsize, -1)], axis=-1)
        obs = np.transpose(obs, (2, 0, 1))
        return obs

    def step(self, action):
        for _ in range(2):
            next_state, reward, done, info = self.env.step(action)
        reward = 0.0
        done = False
        # print(np.mean(next_state['image_observation']), np.mean(next_state['image_desired_goal']))
        obs = np.concatenate([next_state['image_observation'].reshape(self.env.imsize, self.env.imsize, -1),
            next_state['image_desired_goal'].reshape(self.env.imsize, self.env.imsize, -1)], axis=-1)
        obs = np.transpose(obs, (2, 0, 1))
        return obs, reward, done, info

class FrameStack(gym.Wrapper):
    def __init__(self, env, k):
        gym.Wrapper.__init__(self, env)
        self._k = k
        self._frames_s = deque([], maxlen=k)
        self._frames_g = deque([], maxlen=k)
        shp = env.observation_space.shape
        self.obs_dim = int(shp[2]/2)
        self.observation_space = gym.spaces.Box(
            low=0,
            high=1,
            shape=(shp[:-1] + (shp[-1] * k,)),
            dtype=np.float32,
        )
        # self._max_episode_steps = env._max_episode_steps

    def reset(self):
        obs = self.env.reset()
        for _ in range(self._k):
            self._frames_s.append(obs.astype(float)[:self.obs_dim])
            self._frames_g.append(obs.astype(float)[self.obs_dim:])
        return self._get_obs()

    def step(self, action):
        action = np.clip(action, self.action_space.low, self.action_space.high)
        obs, reward, done, info = self.env.step(action)
        self._frames_s.append(obs.astype(float)[:self.obs_dim])
        self._frames_g.append(obs.astype(float)[self.obs_dim:])
        return self._get_obs(), reward, done, info

    def _get_obs(self):
        assert len(self._frames_s) == self._k
        assert len(self._frames_g) == self._k
        return np.concatenate([np.concatenate(list(self._frames_s), axis=0), np.concatenate(list(self._frames_g), axis=0)], axis=0)

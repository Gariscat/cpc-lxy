import argparse
import datetime
import gym
import numpy as np
import itertools
import torch
from cpc import CPC
from cpc_aug import CPC_AUG
from clearning import CLearning
from torch.utils.tensorboard import SummaryWriter
from replay_memory import ReplayMemory, GoalReplayMemory
from wrappers import SawyerWrapper
import time
import kornia

import torch
import torch.nn.functional as F
from torch.optim import Adam
import torch.nn as nn

parser = argparse.ArgumentParser(description='PyTorch Soft Actor-Critic Args')
parser.add_argument('--env_name', default="HalfCheetah-v2",
                    help='Mujoco Gym environment (default: HalfCheetah-v2)')
parser.add_argument('--agent_name', default="cpc",
                    help='Which agent to use (default: CPC)')
parser.add_argument('--policy', default="Gaussian",
                    help='Policy Type: Gaussian | Deterministic (default: Gaussian)')
parser.add_argument('--eval', type=bool, default=True,
                    help='Evaluates a policy a policy every 10 episode (default: True)')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor for reward (default: 0.99)')
parser.add_argument('--tau', type=float, default=0.005, metavar='G',
                    help='target smoothing coefficient(τ) (default: 0.005)')
parser.add_argument('--lr', type=float, default=0.001, metavar='G',
                    help='learning rate (default: 0.0003)')
parser.add_argument('--alpha', type=float, default=0.2, metavar='G',
                    help='Temperature parameter α determines the relative importance of the entropy\
                            term against the reward (default: 0.2)')
parser.add_argument('--automatic_entropy_tuning', type=bool, default=False, metavar='G',
                    help='Automaically adjust α (default: False)')
parser.add_argument('--seed', type=int, default=123456, metavar='N',
                    help='random seed (default: 123456)')
parser.add_argument('--max_steps', type=int, default=100, metavar='N',
                    help='maximum number of steps (default: 100)')
parser.add_argument('--horizon', type=int, default=50, metavar='N',
                    help='horizon of number steps (default: 50)')
parser.add_argument('--relabel_next_prob', type=float, default=0.0, metavar='G',
                    help='probability of relabeling next state (default: 0.0)')
parser.add_argument('--relabel_future_prob', type=float, default=0.5, metavar='G',
                    help='probability of relabeling future state (default: 0.5)')
parser.add_argument('--batch_size', type=int, default=256, metavar='N',
                    help='batch size (default: 256)')
parser.add_argument('--num_steps', type=int, default=1000001, metavar='N',
                    help='maximum number of steps (default: 1000000)')
parser.add_argument('--hidden_size', type=int, default=256, metavar='N',
                    help='hidden size (default: 256)')
parser.add_argument('--updates_per_step', type=int, default=1, metavar='N',
                    help='model updates per simulator step (default: 1)')
parser.add_argument('--steps_per_update', type=int, default=1, metavar='N',
                    help='env steps per update (default: 1)')
parser.add_argument('--start_steps', type=int, default=10000, metavar='N',
                    help='Steps sampling random actions (default: 10000)')
parser.add_argument('--target_update_interval', type=int, default=1, metavar='N',
                    help='Value target update per no. of updates per step (default: 1)')
parser.add_argument('--replay_size', type=int, default=100000, metavar='N',
                    help='size of replay buffer (default: 100000)')
parser.add_argument('--cuda', action="store_false",
                    help='run on CUDA (default: False)')
parser.add_argument('--eval_interval', type=int, default=9000, metavar='N',
                    help='number of steps to evaluate (default: 4000)')
args = parser.parse_args()

# Environment
# env = NormalizedActions(gym.make(args.env_name))
# env = gym.make(args.env_name)
if 'sawyer' not in args.env_name and 'point' not in args.env_name:
    import dmc2gym
    domain_name = args.env_name.split("_")[0]
    task_name = "_".join(args.env_name.split("_")[1:])
    camera_id = 2 if domain_name == "quadruped" else 0
    env = dmc2gym.make(
        domain_name=domain_name,
        task_name=task_name,
        seed=args.seed,
        visualize_reward=False,
        from_pixels=True,
        height=48,
        width=48,
        frame_skip=4,
        camera_id=camera_id,
    )
    in_channel = env.observation_space.shape[0]
elif 'point' in args.env_name:
    from maze_env import *
    env = PointEnvGoal(walls='SixRooms')
    in_channel = env.observation_space.shape[2]
else:
    import cpc_envs
    # from multiworld.envs.mujoco import register_custom_envs as register_mujoco_envs
    # register_mujoco_envs()
    # env = gym.make('Image48SawyerPushAndReachArenaTrainEnvBig-v0')
    # env = SawyerWrapper(env)
    env = cpc_envs.load(args.env_name)
    in_channel = env.observation_space.shape[2]
env.seed(args.seed)
env.action_space.seed(args.seed)

# Agent
if args.agent_name == 'cpc':
    agent = CPC(in_channel, env.action_space, args)
elif args.agent_name == 'cpc_aug':
    agent = CPC_AUG(in_channel, env.action_space, args)
elif args.agent_name == 'clearning':
    agent = CLearning(in_channel, env.action_space, args)

# create dataset 
replay_ckpt_path = "checkpoints/sac_buffer_{}_".format(args.env_name)
dataset = np.load(replay_ckpt_path, allow_pickle=True)
agent_ckpt_path = "checkpoints/sac_checkpoint_{}_".format(args.env_name)
agent.load_checkpoint(agent_ckpt_path)

device = torch.device("cuda" if args.cuda else "cpu")
regress_linear = nn.Linear(args.hidden_size*2, 1).to(device)
optim = Adam(regress_linear.parameters(), lr=args.lr)
dataset['dist'] = (dataset['dist'] - np.mean(dataset['dist'])) / np.std(dataset['dist'])

obs = torch.tensor(dataset['obs'].reshape(-1, in_channel, 64, 64))
act = torch.tensor(dataset['act'].reshape(obs.shape[0], -1))
label = torch.tensor(dataset['dist'].reshape(-1))
train = torch.utils.data.TensorDataset(obs, act, label)
train_loader = torch.utils.data.DataLoader(train, batch_size=64, shuffle=False)

for epoch in range(100):
    train_loss = []
    for i, (data_obs, data_act, data_label) in enumerate(train_loader):
        data_obs = data_obs.to(device)
        data_act = data_act.to(device)
        data_label = data_label.to(device)
        obs1, obs2 = agent.critic.get_state(data_obs, data_act)
        goal1, goal2 = agent.critic.get_goal(data_obs, data_act)
        # print(torch.sigmoid(torch.sum(obs1*goal1, dim=-1)))
        embeddings = torch.concat([obs1, goal1], dim=-1).detach()
        pred = regress_linear(embeddings)
        loss = nn.MSELoss()(pred.squeeze(), data_label)
        train_loss.append(loss.item())

        optim.zero_grad()
        loss.backward()
        optim.step()

    print('Epoch: ', epoch, ' Train Loss: ', sum(train_loss)/len(train_loss))

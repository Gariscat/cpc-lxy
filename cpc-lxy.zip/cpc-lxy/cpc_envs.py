# coding=utf-8
# Copyright 2021 The Google Research Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Load and wrap the d4rl environments.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from absl import logging
import gin
import gym
from metaworld.envs.mujoco import sawyer_xyz
import mujoco_py
import numpy as np
from tf_agents.environments import suite_gym
from tf_agents.environments import tf_py_environment
from tf_agents.environments import wrappers
from maze_env import PointEnvGoal

os.environ['SDL_VIDEODRIVER'] = 'dummy'
MAX_HEIGHT = 0.5
IMSIZE = 64
# IMSIZE = 84

# When collecting trajectory snippets for training, we use discount = 0 to
# decide when to break a trajectory; we don't use the step_type. For data
# collection, we therefore should set done=True only when the environment truly
# terminates, not when we've reached the goal.
# Eventually, we want to create the train_env by taking any gym_env or py_env,
# putting a learned goal-sampling wrapper around it, and then using that.

def load_point_small():
  #TODO: set action_noise to 0.1 now, originally it was 1
  gym_env = PointEnvGoal(walls='Small')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=20,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_cross():
  gym_env = PointEnvGoal(walls='Cross')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=50,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_fourroom():
  gym_env = PointEnvGoal(walls='FourRooms')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=100,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_sixroom():
  gym_env = PointEnvGoal(walls='SixRooms')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=100,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_elevenmaze():
  gym_env = PointEnvGoal(walls='Maze11x11')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=200,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_galton():
  gym_env = PointEnvGoal(walls='Galton')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=100,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_flytrapsmall():
  gym_env = PointEnvGoal(walls='FlyTrapSmall')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=100,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_flytrapbig():
  gym_env = PointEnvGoal(walls='FlyTrapBig')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=100,
  )
  return tf_py_environment.TFPyEnvironment(env) 

def load_point_tree():
  gym_env = PointEnvGoal(walls='Tree')
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=200,
  )
  return tf_py_environment.TFPyEnvironment(env) 

from multiworld.core.image_env import ImageEnv
from wrappers import SawyerWrapper, FrameStack
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from gym.spaces import Box, Dict

def load_sawyer_reach():
  gym_env = SawyerReach()
  gym_env = ImageEnv(gym_env, IMSIZE, normalize=True)
  gym_env = SawyerWrapper(gym_env)
  return gym_env

class SawyerReach(sawyer_xyz.SawyerReachPushPickPlaceEnv):
  """Wrapper for the sawyer_reach task."""

  def __init__(self):
    super(SawyerReach, self).__init__(task_type='reach', goal_low=(-0.1, 0.8, 0.15), goal_high=(0.1, 0.9, 0.15))
    self.observation_space = gym.spaces.Box(
        low=np.full(6, -np.inf),
        high=np.full(6, np.inf),
        dtype=np.float32)
    self.observation_space = Dict([
            ('observation', self.observation_space),
            ('desired_goal', self.observation_space),
            ('achieved_goal', self.observation_space),
            ('state_observation', self.observation_space),
            ('state_desired_goal', self.observation_space),
            ('state_achieved_goal', self.observation_space),
            ('proprio_observation', self.observation_space),
            ('proprio_desired_goal', self.observation_space),
            ('proprio_achieved_goal', self.observation_space),
        ])

    # hand_low=(-0.5, 0.40, 0.05)
    # hand_high=(0.5, 1, 0.5)
    # obj_low=(-0.1, 0.6, 0.02)
    # obj_high=(0.1, 0.7, 0.02)

    hand_low=np.array([-0.1, 0.60])
    hand_high=np.array([0.1, 0.9])
    obj_low=np.array([-0.1, 0.6])
    obj_high=np.array([0.1, 0.9])
    
    # TODO: changes here
    imsize = IMSIZE
    fig, ax = plt.subplots()
    marker_factor = 0.5
    self.marker_factor = marker_factor
    x_bounds = np.array([hand_low[0] - 0.03, hand_high[0] + 0.03])
    y_bounds = np.array([hand_low[1] - 0.03, hand_high[1] + 0.03])
    self.vis_bounds = np.concatenate((x_bounds, y_bounds))
    extent = self.vis_bounds

    ax.set_ylim(extent[2:4])
    ax.set_xlim(extent[0:2])
    ax.set_ylim(ax.get_ylim()[::-1])
    ax.set_xlim(ax.get_xlim()[::-1])
    DPI = fig.get_dpi()
    fig.set_size_inches(imsize / float(DPI), imsize / float(DPI))

    ax.vlines(x=hand_low[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_low[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')
    ax.vlines(x=hand_high[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_high[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')

    ax.vlines(x=obj_low[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_low[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')
    ax.vlines(x=obj_high[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_high[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')

    self.plt_state_hand = plt.Circle((hand_low+hand_high)/2, 0.025 * marker_factor, color='green')
    ax.add_artist(self.plt_state_hand)
    self.plt_state_puck = plt.Circle((obj_low+obj_high)/2, 0.025 * marker_factor, color='blue')
    ax.add_artist(self.plt_state_puck)
    # self.plt_goal_hand = plt.Circle((hand_low+hand_high)/2, 0.03 * marker_factor, color='#00ff99')
    # ax.add_artist(self.plt_goal_hand)
    # self.plt_goal_puck = plt.Circle((obj_low+obj_high)/2, 0.03 * marker_factor, color='cyan')
    # ax.add_artist(self.plt_goal_puck)

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    fig.subplots_adjust(bottom=0)
    fig.subplots_adjust(top=1)
    fig.subplots_adjust(right=1)
    fig.subplots_adjust(left=0)
    ax.axis('off')
    # fig.canvas.draw()
    self.bg = fig.canvas.copy_from_bbox(fig.bbox)
    self.ax = ax
    self.fig = fig
  
    self._get_viewer('rgb_array')
    self.viewer.cam.azimuth = 270
    self.viewer.cam.distance = 1.5
    self.viewer.cam.lookat[2] = -0.2
    
    '''
    self.viewer.cam.lookat[0] = 0
    self.viewer.cam.lookat[1] = 0.4
    self.viewer.cam.lookat[2] = 0.3
    self.viewer.cam.distance = 0.4
    self.viewer.cam.elevation = -35
    self.viewer.cam.azimuth = 270
    self.viewer.cam.trackbodyid = -1
    '''
 
  def set_to_goal(self, goal):
    state_goal = goal['state_desired_goal']
    self._set_hand_xy(state_goal[:3])
    # self._set_puck_xy(state_goal[-3:])

  def _set_hand_xy(self, xy):
    for _ in range(10):
      self.data.set_mocap_pos('mocap', np.array([xy[0], xy[1], xy[2]])) #0.02
      self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
      self.do_simulation([-1,1], self.frame_skip)

  def _set_puck_xy(self, pos):
    qpos = self.data.qpos.flat.copy()
    qvel = self.data.qvel.flat.copy()
    qpos[7:10] = pos.copy()
    qvel[7:10] = [0, 0, 0]
    self.set_state(qpos, qvel)

  def compute_rewards(self, actions, obsBatch, prev_obs=None):
    #Required by HER-TD3
    assert isinstance(obsBatch, dict) == True
    obsList = obsBatch['state_observation']
    rewards = [self.compute_reward(action, obs, task_type=self.task_type)[0] for  action, obs in zip(actions, obsList)]
    return np.array(rewards)

  def reset(self):
    goal = self.sample_goals(1)['state_desired_goal'][0]
    self.goal = goal
    self._state_goal = goal
    return self.reset_model()

  def step(self, action):
    s, r, done, info = super(SawyerReach, self).step(action)
    r = 0.0
    done = False
    # print(s['state_observation'][:3], self._state_goal)
    info.update({'state_distance': np.linalg.norm(s['state_observation'][:3] - self._state_goal)})
    # info.update({'state_distance': np.linalg.norm(s['state_observation'][:2] - self._state_goal[:2])})
    return s, r, done, info

  def _get_obs(self):
    e = self.get_endeff_pos()
    b = self.get_obj_pos()
    flat_obs = np.concatenate((e, b))

    return dict(
      observation=flat_obs,
      desired_goal=self._state_goal,
      achieved_goal=flat_obs,
      state_observation=flat_obs,
      state_desired_goal=self._state_goal,
      state_achieved_goal=flat_obs,
      proprio_observation=flat_obs,
      proprio_desired_goal=self._state_goal,
      proprio_achieved_goal=flat_obs,)

  def get_image(self, imsize):
    self._set_goal_marker(self._state_goal)
    img = self.render(mode='rgb_array', width=64, height=64)
    # img = self.get_image_plt(self.fig, self.ax, imsize=imsize, draw_state=True, draw_goal=True, draw_subgoals=True)
    # print(np.mean(img), np.std(img))
    return img

  def get_image_plt(self, fig, ax, vals=None, extent=None,
          imsize=84, draw_state=True, draw_goal=False, draw_subgoals=False,
          state=None, goal=None, subgoals=None):
    marker_factor = self.marker_factor
    # fig.canvas.restore_region(self.bg)
    hand_pos = self.get_endeff_pos()
    puck_pos = self.get_obj_pos()
    self.plt_state_hand.center = hand_pos[0], hand_pos[1]
    self.plt_state_puck.center = puck_pos[0], puck_pos[1]
    # self.plt_goal_hand.center = self._state_goal[0], self._state_goal[1]
    # self.plt_goal_puck.center = self._state_goal[-2], self._state_goal[-1]
    img = self.plt_to_numpy(fig)
 
    # heatmap_h = np.expand_dims((img[:, :, 1] == 255).astype(float), axis=-1)
    # heatmap_p = np.expand_dims((img[:, :, 2] == 255).astype(float), axis=-1)
    heatmap_h = np.ones(img.shape[:-1] + (1,))
    heatmap_p = np.ones(img.shape[:-1] + (1,))
    hand_height = heatmap_h * hand_pos[2] * 255
    puck_height = heatmap_p * puck_pos[2] * 255
    img = np.concatenate([img, hand_height, puck_height], axis=-1)
    return img 

  def get_obj_pos(self):
    return self.data.get_geom_xpos('objGeom')

  def plt_to_numpy(self, fig):
    fig.canvas.draw()
    data = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    return data
 
def load_sawyer_reachwall():
  gym_env = SawyerReachWall()
  gym_env = ImageEnv(gym_env, IMSIZE, normalize=True)
  gym_env = SawyerWrapper(gym_env)
  return gym_env

class SawyerReachWall(sawyer_xyz.SawyerReachPushPickPlaceWallEnv):
  """Wrapper for the sawyer_reach task."""

  def __init__(self):
    super(SawyerReachWall, self).__init__(task_type='reach', goal_low=(-0.1, 0.85, 0.05), goal_high=(0.1, 0.9, 0.05))
    self.observation_space = gym.spaces.Box(
        low=np.full(6, -np.inf),
        high=np.full(6, np.inf),
        dtype=np.float32)
    self.observation_space = Dict([
            ('observation', self.observation_space),
            ('desired_goal', self.observation_space),
            ('achieved_goal', self.observation_space),
            ('state_observation', self.observation_space),
            ('state_desired_goal', self.observation_space),
            ('state_achieved_goal', self.observation_space),
            ('proprio_observation', self.observation_space),
            ('proprio_desired_goal', self.observation_space),
            ('proprio_achieved_goal', self.observation_space),
        ])

    # hand_low=(-0.5, 0.40, 0.05)
    # hand_high=(0.5, 1, 0.5)
    # obj_low=(-0.1, 0.6, 0.02)
    # obj_high=(0.1, 0.7, 0.02)

    hand_low=np.array([-0.5, 0.40])
    hand_high=np.array([0.5, 1.0])
    obj_low=np.array([-0.5, 0.4])
    obj_high=np.array([0.5, 1.0])
    
    # TODO: changes here
    imsize = IMSIZE
    fig, ax = plt.subplots()
    marker_factor = 1.0
    self.marker_factor = marker_factor
    x_bounds = np.array([hand_low[0] - 0.03, hand_high[0] + 0.03])
    y_bounds = np.array([hand_low[1] - 0.03, hand_high[1] + 0.03])
    self.vis_bounds = np.concatenate((x_bounds, y_bounds))
    extent = self.vis_bounds

    ax.set_ylim(extent[2:4])
    ax.set_xlim(extent[0:2])
    ax.set_ylim(ax.get_ylim()[::-1])
    ax.set_xlim(ax.get_xlim()[::-1])
    DPI = fig.get_dpi()
    fig.set_size_inches(imsize / float(DPI), imsize / float(DPI))

    ax.vlines(x=hand_low[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_low[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')
    ax.vlines(x=hand_high[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_high[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')

    ax.vlines(x=obj_low[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_low[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')
    ax.vlines(x=obj_high[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_high[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')

    self.plt_state_hand = plt.Circle((hand_low+hand_high)/2, 0.025 * marker_factor, color='green')
    ax.add_artist(self.plt_state_hand)
    self.plt_state_puck = plt.Circle((obj_low+obj_high)/2, 0.025 * marker_factor, color='blue')
    ax.add_artist(self.plt_state_puck)
    # self.plt_goal_hand = plt.Circle((hand_low+hand_high)/2, 0.03 * marker_factor, color='#00ff99')
    # ax.add_artist(self.plt_goal_hand)
    # self.plt_goal_puck = plt.Circle((obj_low+obj_high)/2, 0.03 * marker_factor, color='cyan')
    # ax.add_artist(self.plt_goal_puck)

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    fig.subplots_adjust(bottom=0)
    fig.subplots_adjust(top=1)
    fig.subplots_adjust(right=1)
    fig.subplots_adjust(left=0)
    ax.axis('off')
    # fig.canvas.draw()
    self.bg = fig.canvas.copy_from_bbox(fig.bbox)
    self.ax = ax
    self.fig = fig
  
    self._get_viewer('rgb_array')
    # self.viewer.cam.azimuth = 270
    # self.viewer.cam.distance = 1.5
    # self.viewer.cam.lookat[2] = -0.2
    
    self.viewer.cam.lookat[0] = 0
    self.viewer.cam.lookat[1] = 0.4
    self.viewer.cam.lookat[2] = 0.3
    self.viewer.cam.distance = 0.4
    self.viewer.cam.elevation = -35
    self.viewer.cam.azimuth = 270
    self.viewer.cam.trackbodyid = -1
 
  def set_to_goal(self, goal):
    state_goal = goal['state_desired_goal']
    self._set_hand_xy(state_goal[:3])
    # self._set_puck_xy(state_goal[-3:])

  def _set_hand_xy(self, xy):
    for _ in range(10):
      self.data.set_mocap_pos('mocap', np.array([xy[0], xy[1], xy[2]])) #0.02
      self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
      self.do_simulation([-1,1], self.frame_skip)

  def _set_puck_xy(self, pos):
    qpos = self.data.qpos.flat.copy()
    qvel = self.data.qvel.flat.copy()
    qpos[7:10] = pos.copy()
    qvel[7:10] = [0, 0, 0]
    self.set_state(qpos, qvel)

  def compute_rewards(self, actions, obsBatch, prev_obs=None):
    #Required by HER-TD3
    assert isinstance(obsBatch, dict) == True
    obsList = obsBatch['state_observation']
    rewards = [self.compute_reward(action, obs, task_type=self.task_type)[0] for  action, obs in zip(actions, obsList)]
    return np.array(rewards)

  def reset(self):
    goal = self.sample_goals(1)['state_desired_goal'][0]
    self.goal = goal
    self._state_goal = goal
    return self.reset_model()

  def step(self, action):
    s, r, done, info = super(SawyerReachWall, self).step(action)
    r = 0.0
    done = False
    # print(s['state_observation'][:3], self._state_goal)
    info.update({'state_distance': np.linalg.norm(s['state_observation'][:3] - self._state_goal)})
    # info.update({'state_distance': np.linalg.norm(s['state_observation'][:2] - self._state_goal[:2])})
    return s, r, done, info

  def _get_obs(self):
    e = self.get_endeff_pos()
    b = self.get_obj_pos()
    flat_obs = np.concatenate((e, b))

    return dict(
      observation=flat_obs,
      desired_goal=self._state_goal,
      achieved_goal=flat_obs,
      state_observation=flat_obs,
      state_desired_goal=self._state_goal,
      state_achieved_goal=flat_obs,
      proprio_observation=flat_obs,
      proprio_desired_goal=self._state_goal,
      proprio_achieved_goal=flat_obs,)

  def get_image(self, imsize):
    self._set_goal_marker(self._state_goal)
    # img = self.render(mode='rgb_array', width=48, height=48)
    img = self.get_image_plt(self.fig, self.ax, imsize=imsize, draw_state=True, draw_goal=True, draw_subgoals=True)
    # print(np.mean(img), np.std(img))
    return img

  def get_image_plt(self, fig, ax, vals=None, extent=None,
          imsize=84, draw_state=True, draw_goal=False, draw_subgoals=False,
          state=None, goal=None, subgoals=None):
    marker_factor = self.marker_factor
    # fig.canvas.restore_region(self.bg)
    hand_pos = self.get_endeff_pos()
    puck_pos = self.get_obj_pos()
    self.plt_state_hand.center = hand_pos[0], hand_pos[1]
    self.plt_state_puck.center = puck_pos[0], puck_pos[1]
    # self.plt_goal_hand.center = self._state_goal[0], self._state_goal[1]
    # self.plt_goal_puck.center = self._state_goal[-2], self._state_goal[-1]
    img = self.plt_to_numpy(fig)
 
    # heatmap_h = np.expand_dims((img[:, :, 1] == 255).astype(float), axis=-1)
    # heatmap_p = np.expand_dims((img[:, :, 2] == 255).astype(float), axis=-1)
    heatmap_h = np.ones(img.shape[:-1] + (1,))
    heatmap_p = np.ones(img.shape[:-1] + (1,))
    hand_height = heatmap_h * hand_pos[2] * 255
    puck_height = heatmap_p * puck_pos[2] * 255
    img = np.concatenate([img, hand_height, puck_height], axis=-1)
    return img 

  def get_obj_pos(self):
    return self.data.get_geom_xpos('objGeom')

  def plt_to_numpy(self, fig):
    fig.canvas.draw()
    data = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    return data
 
@gin.configurable
def load_sawyer_push(random_init=True, wide_goals=False,
                     include_gripper=False):
  """Load the sawyer pushing (and picking) environment.
  Args:
    random_init: (bool) Whether to randomize the initial arm position.
    wide_goals: (bool) Whether to use a wider range of Y positions for goals.
      The Y axis parallels the ground, pointing from the robot to the table.
    include_gripper: (bool) Whether to include the gripper open/close state in
      the observation.
  Returns:
    tf_env: An environment.
  """
  if wide_goals:
    goal_low = (-0.1, 0.5, 0.05)
  else:
    goal_low = (-0.1, 0.8, 0.05)
  if include_gripper:
    gym_env = SawyerPushGripper(random_init=random_init)
  else:
    gym_env = SawyerPush(random_init=random_init)
  gym_env = ImageEnv(gym_env, IMSIZE, normalize=True)
  gym_env = SawyerWrapper(gym_env)
  gym_env = FrameStack(gym_env, 3)
  return gym_env

class SawyerPush(sawyer_xyz.SawyerReachPushPickPlaceEnv):
  """Wrapper for the sawyer_reach task."""

  def __init__(self, random_init=False):
    random_init = False
    # super(SawyerPush, self).__init__(task_type='push', random_init=random_init, goal_low=(-0.1, 0.7, 0.05), goal_high=(0.1, 0.8, 0.05))
    super(SawyerPush, self).__init__(task_type='push', random_init=random_init, goal_low=(-0.0, 0.8, 0.05), goal_high=(0.0, 0.9, 0.05))
    self.observation_space = gym.spaces.Box(
        low=np.full(6, -np.inf),
        high=np.full(6, np.inf),
        dtype=np.float32)
    self.observation_space = Dict([
            ('observation', self.observation_space),
            ('desired_goal', self.observation_space),
            ('achieved_goal', self.observation_space),
            ('state_observation', self.observation_space),
            ('state_desired_goal', self.observation_space),
            ('state_achieved_goal', self.observation_space),
            ('proprio_observation', self.observation_space),
            ('proprio_desired_goal', self.observation_space),
            ('proprio_achieved_goal', self.observation_space),
        ])

    # hand_low=(-0.5, 0.40, 0.05)
    # hand_high=(0.5, 1, 0.5)
    # obj_low=(-0.1, 0.6, 0.02)
    # obj_high=(0.1, 0.7, 0.02)

    hand_low=np.array([-0.5, 0.40])
    hand_high=np.array([0.5, 1])
    obj_low=np.array([-0.5, 0.4])
    obj_high=np.array([0.5, 1.0])
    
    # TODO: changes here
    imsize = IMSIZE
    fig, ax = plt.subplots()
    marker_factor = 1.0
    self.marker_factor = marker_factor
    x_bounds = np.array([hand_low[0] - 0.03, hand_high[0] + 0.03])
    y_bounds = np.array([hand_low[1] - 0.03, hand_high[1] + 0.03])
    self.vis_bounds = np.concatenate((x_bounds, y_bounds))
    extent = self.vis_bounds

    ax.set_ylim(extent[2:4])
    ax.set_xlim(extent[0:2])
    ax.set_ylim(ax.get_ylim()[::-1])
    ax.set_xlim(ax.get_xlim()[::-1])
    DPI = fig.get_dpi()
    fig.set_size_inches(imsize / float(DPI), imsize / float(DPI))

    ax.vlines(x=hand_low[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_low[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')
    ax.vlines(x=hand_high[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_high[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')

    ax.vlines(x=obj_low[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_low[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')
    ax.vlines(x=obj_high[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_high[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')

    self.plt_state_hand = plt.Circle((hand_low+hand_high)/2, 0.025 * marker_factor, color='green')
    ax.add_artist(self.plt_state_hand)
    self.plt_state_puck = plt.Circle((obj_low+obj_high)/2, 0.025 * marker_factor, color='blue')
    ax.add_artist(self.plt_state_puck)
    # self.plt_goal_hand = plt.Circle((hand_low+hand_high)/2, 0.03 * marker_factor, color='#00ff99')
    # ax.add_artist(self.plt_goal_hand)
    # self.plt_goal_puck = plt.Circle((obj_low+obj_high)/2, 0.03 * marker_factor, color='cyan')
    # ax.add_artist(self.plt_goal_puck)

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    fig.subplots_adjust(bottom=0)
    fig.subplots_adjust(top=1)
    fig.subplots_adjust(right=1)
    fig.subplots_adjust(left=0)
    ax.axis('off')
    # fig.canvas.draw()
    self.bg = fig.canvas.copy_from_bbox(fig.bbox)
    self.ax = ax
    self.fig = fig
    
    self._get_viewer('rgb_array')
    # self._get_viewer('human')
    # self.viewer.cam.azimuth = 360
    # self.viewer.cam.distance = 0.8
    # self.viewer.cam.lookat[1] = 0.7
    # self.viewer.cam.lookat[0] = 0.1
    # self.viewer.cam.lookat[2] = -0.0
    '''
    self.viewer.cam.azimuth = -20
    self.viewer.cam.elevation = -20
    self.viewer.cam.distance = 0.9
    self.viewer.cam.lookat[1] = 0.7
    '''
    '''
    # self.viewer.cam.azimuth =  205
    self.viewer.cam.azimuth = 300
    self.viewer.cam.elevation = -164
    # self.viewer.cam.distance = 2.3
    # self.viewer.cam.distance = 1.2
    self.viewer.cam.distance = 1.8
    # self.viewer.cam.lookat[0] = 1.1
    # self.viewer.cam.lookat[0] = 0.5
    self.viewer.cam.lookat[0] = 0.8
    self.viewer.cam.lookat[1] = 1.1 
    # self.viewer.cam.lookat[1] = 0.8
    self.viewer.cam.lookat[2] = -0.1
    '''
    # self.viewer.cam.azimuth = 345
    self.viewer.cam.azimuth = 235
    # self.viewer.cam.azimuth = 225
    self.viewer.cam.distance = 0.9
    # self.viewer.cam.lookat[1] = 0.5
    self.viewer.cam.lookat[1] = 0.6
    # self.viewer.cam.lookat[2] = -0.05
    self.viewer.cam.lookat[2] = -0.0
    self.viewer.cam.elevation = -40

  def set_to_goal(self, goal):
    state_goal = goal['state_desired_goal']
    self._set_hand_xy(self._arm_goal[:3])
    self._set_puck_xy(state_goal[:3])

  def _set_hand_xy(self, xy):
    for _ in range(10):
      self.data.set_mocap_pos('mocap', np.array([xy[0], xy[1], xy[2]])) #0.02
      self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
      self.do_simulation([-1,1], self.frame_skip)

  def _set_puck_xy(self, pos):
    # qpos = self.data.qpos.flat.copy()
    # qvel = self.data.qvel.flat.copy()
    # qpos[7:10] = pos.copy()
    # qvel[7:10] = [0, 0, 0]
    # self.set_state(qpos, qvel)
    self._set_obj_xyz_quat(pos, 0.0)

  def compute_rewards(self, actions, obsBatch, prev_obs=None):
    #Required by HER-TD3
    assert isinstance(obsBatch, dict) == True
    obsList = obsBatch['state_observation']
    rewards = [self.compute_reward(action, obs, task_type=self.task_type)[0] for  action, obs in zip(actions, obsList)]
    return np.array(rewards)

  def reset(self,
            arm_goal_type='goal',
            fix_z=True,
            fix_xy=False,
            fix_g=False,
            reset_puck=False,
            in_hand_prob=0.0,
            custom_eval=False,
            reset_to_puck_prob=0.0):
    assert arm_goal_type in ['random', 'puck', 'goal']
    if custom_eval and self.MODE == 'eval':
      arm_goal_type = 'goal'
      in_hand_prob = 0
      reset_to_puck_prob = 0.0
    self._arm_goal_type = arm_goal_type
    # The arm_goal seems to be set to some (dummy) value before we can reset
    # the environment.
    self._arm_goal = np.zeros(3)
    if fix_g:
      self._gripper_goal = np.array([0.016])
    else:
      self._gripper_goal = np.random.uniform(0, 0.04, (1,))
    obs = super(SawyerPush, self).reset()
    if reset_puck:
      puck_pos = self.sample_goals(1)['state_desired_goal'][0]
      puck_pos[2] = 0.015
    else:
      puck_pos = obs['observation'][3:6]
    # The following line ensures that the puck starts face-up, not on edge.
    # puck_pos[2] = 0.015
    #TODO: added here
    # puck_pos = [0.0, 0.6, puck_pos[2]]
    self._set_obj_xyz_quat(puck_pos, 0.0)
    if np.random.random() < reset_to_puck_prob:
      obs = self._get_obs()
      for _ in range(10):
        self.data.set_mocap_pos('mocap', obs[3:6])
        self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
        self.do_simulation([-1, 1], self.frame_skip)

    if np.random.random() < in_hand_prob:
      for _ in range(10):
        obs, _, _, _ = self.step(np.array([0, 0, 0, 1]))
      hand_pos = self.get_endeff_pos()
      self._set_obj_xyz_quat(hand_pos[:3], 0.0)
    obs = self._get_obs()

    self.goal = self.sample_goals(1)['state_desired_goal'][0]
    if fix_z:
      self.goal[2] = 0.015
    if fix_xy:
      self.goal[:2] = obs[3:5]

    self._set_goal_marker(self.goal)
    self._state_goal = self.goal.copy()

    if arm_goal_type == 'random':
      self._arm_goal = self.sample_goals(1)['state_desired_goal'][0]
      if fix_z:
        self._arm_goal[2] = 0.015
    elif arm_goal_type == 'puck':
      self._arm_goal = obs[3:6]
    elif arm_goal_type == 'goal':
      self._arm_goal = self.goal.copy()
      self._arm_goal[2] = 0.05
      # self._arm_goal[2] = 0.2
    else:
      raise NotImplementedError
    return self._get_obs()

  def step(self, action):
    s, r, done, info = super(SawyerPush, self).step(action)
    r = 0.0
    done = False
    # print(s['state_observation'][:3], self._state_goal)
    info.update({'state_distance': np.linalg.norm(s['state_observation'][3:] - self._state_goal)})
    return s, r, done, info

  def _get_obs(self):
    e = self.get_endeff_pos()
    b = self.get_obj_pos()
    flat_obs = np.concatenate((e, b))

    return dict(
      observation=flat_obs,
      desired_goal=self._state_goal,
      achieved_goal=flat_obs,
      state_observation=flat_obs,
      state_desired_goal=self._state_goal,
      state_achieved_goal=flat_obs,
      proprio_observation=flat_obs,
      proprio_desired_goal=self._state_goal,
      proprio_achieved_goal=flat_obs,)

  def get_image(self, imsize):
    self._set_goal_marker(self.goal)
    img = self.render(mode='rgb_array', width=64, height=64)
    # img = self.render(mode='rgb_array', width=84, height=84)
    # img = self.get_image_plt(self.fig, self.ax, imsize=imsize, draw_state=True, draw_goal=True, draw_subgoals=True)
    return img

  def get_image_plt(self, fig, ax, vals=None, extent=None,
          imsize=84, draw_state=True, draw_goal=False, draw_subgoals=False,
          state=None, goal=None, subgoals=None):
    marker_factor = self.marker_factor
    # fig.canvas.restore_region(self.bg)
    hand_pos = self.get_endeff_pos()
    puck_pos = self.get_obj_pos()
    self.plt_state_hand.center = hand_pos[0], hand_pos[1]
    self.plt_state_puck.center = puck_pos[0], puck_pos[1]
    # self.plt_goal_hand.center = self._state_goal[0], self._state_goal[1]
    # self.plt_goal_puck.center = self._state_goal[-2], self._state_goal[-1]
    img = self.plt_to_numpy(fig)

    heatmap_h = np.expand_dims((img[:, :, 1] == 255).astype(float), axis=-1)
    heatmap_p = np.expand_dims((img[:, :, 2] == 255).astype(float), axis=-1)
    hand_height = heatmap_h * hand_pos[2] * 255
    puck_height = heatmap_p * puck_pos[2] * 255
    img = np.concatenate([img, hand_height, puck_height], axis=-1)
    # print(hand_pos, puck_pos)
    return img
  
  def get_obj_pos(self):
    return self.data.get_geom_xpos('objGeom')

  def plt_to_numpy(self, fig):
    fig.canvas.draw()
    data = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    return data
 
@gin.configurable
def load_sawyer_pushwall(random_init=True, wide_goals=False,
                     include_gripper=False):
  """Load the sawyer pushing (and picking) environment.
  Args:
    random_init: (bool) Whether to randomize the initial arm position.
    wide_goals: (bool) Whether to use a wider range of Y positions for goals.
      The Y axis parallels the ground, pointing from the robot to the table.
    include_gripper: (bool) Whether to include the gripper open/close state in
      the observation.
  Returns:
    tf_env: An environment.
  """
  if wide_goals:
    goal_low = (-0.1, 0.5, 0.05)
  else:
    goal_low = (-0.1, 0.8, 0.05)
  if include_gripper:
    gym_env = SawyerPushGripper(random_init=random_init)
  else:
    gym_env = SawyerPushWall(random_init=random_init)
  gym_env = ImageEnv(gym_env, IMSIZE, normalize=True)
  gym_env = SawyerWrapper(gym_env)
  # gym_env = FrameStack(gym_env, 1)
  return gym_env

class SawyerPushWall(sawyer_xyz.SawyerReachPushPickPlaceWallEnv):
  """Wrapper for the sawyer_reach task."""

  def __init__(self, random_init=False):
    super(SawyerPushWall, self).__init__(task_type='push', random_init=random_init, goal_low=(-0.1, 0.6, 0.05), goal_high=(0.1, 0.9, 0.05))
    self.observation_space = gym.spaces.Box(
        low=np.full(6, -np.inf),
        high=np.full(6, np.inf),
        dtype=np.float32)
    self.observation_space = Dict([
            ('observation', self.observation_space),
            ('desired_goal', self.observation_space),
            ('achieved_goal', self.observation_space),
            ('state_observation', self.observation_space),
            ('state_desired_goal', self.observation_space),
            ('state_achieved_goal', self.observation_space),
            ('proprio_observation', self.observation_space),
            ('proprio_desired_goal', self.observation_space),
            ('proprio_achieved_goal', self.observation_space),
        ])

    # hand_low=(-0.5, 0.40, 0.05)
    # hand_high=(0.5, 1, 0.5)
    # obj_low=(-0.1, 0.6, 0.02)
    # obj_high=(0.1, 0.7, 0.02)

    hand_low=np.array([-0.5, 0.40])
    hand_high=np.array([0.5, 1])
    obj_low=np.array([-0.5, 0.4])
    obj_high=np.array([0.5, 1.0])
    
    # TODO: changes here
    imsize = IMSIZE
    fig, ax = plt.subplots()
    marker_factor = 1.0
    self.marker_factor = marker_factor
    x_bounds = np.array([hand_low[0] - 0.03, hand_high[0] + 0.03])
    y_bounds = np.array([hand_low[1] - 0.03, hand_high[1] + 0.03])
    self.vis_bounds = np.concatenate((x_bounds, y_bounds))
    extent = self.vis_bounds

    ax.set_ylim(extent[2:4])
    ax.set_xlim(extent[0:2])
    ax.set_ylim(ax.get_ylim()[::-1])
    ax.set_xlim(ax.get_xlim()[::-1])
    DPI = fig.get_dpi()
    fig.set_size_inches(imsize / float(DPI), imsize / float(DPI))

    ax.vlines(x=hand_low[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_low[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')
    ax.vlines(x=hand_high[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_high[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')

    ax.vlines(x=obj_low[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_low[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')
    ax.vlines(x=obj_high[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_high[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')

    self.plt_state_hand = plt.Circle((hand_low+hand_high)/2, 0.025 * marker_factor, color='green')
    ax.add_artist(self.plt_state_hand)
    self.plt_state_puck = plt.Circle((obj_low+obj_high)/2, 0.025 * marker_factor, color='blue')
    ax.add_artist(self.plt_state_puck)
    # self.plt_goal_hand = plt.Circle((hand_low+hand_high)/2, 0.03 * marker_factor, color='#00ff99')
    # ax.add_artist(self.plt_goal_hand)
    # self.plt_goal_puck = plt.Circle((obj_low+obj_high)/2, 0.03 * marker_factor, color='cyan')
    # ax.add_artist(self.plt_goal_puck)

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    fig.subplots_adjust(bottom=0)
    fig.subplots_adjust(top=1)
    fig.subplots_adjust(right=1)
    fig.subplots_adjust(left=0)
    ax.axis('off')
    # fig.canvas.draw()
    self.bg = fig.canvas.copy_from_bbox(fig.bbox)
    self.ax = ax
    self.fig = fig
    
    self._get_viewer('rgb_array')
    self.viewer.cam.azimuth = 270
    self.viewer.cam.distance = 1.5
    self.viewer.cam.lookat[2] = -0.2

  def set_to_goal(self, goal):
    state_goal = goal['state_desired_goal']
    self._set_hand_xy(self._arm_goal[:3])
    self._set_puck_xy(state_goal[:3])

  def _set_hand_xy(self, xy):
    for _ in range(10):
      self.data.set_mocap_pos('mocap', np.array([xy[0], xy[1], xy[2]])) #0.02
      self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
      self.do_simulation([-1,1], self.frame_skip)

  def _set_puck_xy(self, pos):
    # qpos = self.data.qpos.flat.copy()
    # qvel = self.data.qvel.flat.copy()
    # qpos[7:10] = pos.copy()
    # qvel[7:10] = [0, 0, 0]
    # self.set_state(qpos, qvel)
    self._set_obj_xyz_quat(pos, 0.0)

  def compute_rewards(self, actions, obsBatch, prev_obs=None):
    #Required by HER-TD3
    assert isinstance(obsBatch, dict) == True
    obsList = obsBatch['state_observation']
    rewards = [self.compute_reward(action, obs, task_type=self.task_type)[0] for  action, obs in zip(actions, obsList)]
    return np.array(rewards)

  def reset(self,
            arm_goal_type='goal',
            fix_z=True,
            fix_xy=False,
            fix_g=False,
            reset_puck=False,
            in_hand_prob=0.0,
            custom_eval=False,
            reset_to_puck_prob=0.0):
    assert arm_goal_type in ['random', 'puck', 'goal']
    if custom_eval and self.MODE == 'eval':
      arm_goal_type = 'goal'
      in_hand_prob = 0
      reset_to_puck_prob = 0.0
    self._arm_goal_type = arm_goal_type
    # The arm_goal seems to be set to some (dummy) value before we can reset
    # the environment.
    self._arm_goal = np.zeros(3)
    if fix_g:
      self._gripper_goal = np.array([0.016])
    else:
      self._gripper_goal = np.random.uniform(0, 0.04, (1,))
    obs = super(SawyerPushWall, self).reset()
    if reset_puck:
      puck_pos = self.sample_goals(1)['state_desired_goal'][0]
      puck_pos[2] = 0.015
    else:
      puck_pos = obs['observation'][3:6]
    # The following line ensures that the puck starts face-up, not on edge.
    # puck_pos[2] = 0.015
    self._set_obj_xyz_quat(puck_pos, 0.0)
    if np.random.random() < reset_to_puck_prob:
      obs = self._get_obs()
      for _ in range(10):
        self.data.set_mocap_pos('mocap', obs[3:6])
        self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
        self.do_simulation([-1, 1], self.frame_skip)

    if np.random.random() < in_hand_prob:
      for _ in range(10):
        obs, _, _, _ = self.step(np.array([0, 0, 0, 1]))
      hand_pos = self.get_endeff_pos()
      self._set_obj_xyz_quat(hand_pos[:3], 0.0)
    obs = self._get_obs()

    self.goal = self.sample_goals(1)['state_desired_goal'][0]
    if fix_z:
      self.goal[2] = 0.015
    if fix_xy:
      self.goal[:2] = obs[3:5]

    self._set_goal_marker(self.goal)
    self._state_goal = self.goal.copy()

    if arm_goal_type == 'random':
      self._arm_goal = self.sample_goals(1)['state_desired_goal'][0]
      if fix_z:
        self._arm_goal[2] = 0.015
    elif arm_goal_type == 'puck':
      self._arm_goal = obs[3:6]
    elif arm_goal_type == 'goal':
      self._arm_goal = self.goal.copy() + np.random.randn(self.goal.shape[0]) * 0.0
    else:
      raise NotImplementedError
    return self._get_obs()

  def step(self, action):
    s, r, done, info = super(SawyerPushWall, self).step(action)
    r = 0.0
    done = False
    # print(s['state_observation'][:3], self._state_goal)
    info.update({'state_distance': np.linalg.norm(s['state_observation'][3:] - self._state_goal)})
    return s, r, done, info

  def _get_obs(self):
    e = self.get_endeff_pos()
    b = self.get_obj_pos()
    flat_obs = np.concatenate((e, b))

    return dict(
      observation=flat_obs,
      desired_goal=self._state_goal,
      achieved_goal=flat_obs,
      state_observation=flat_obs,
      state_desired_goal=self._state_goal,
      state_achieved_goal=flat_obs,
      proprio_observation=flat_obs,
      proprio_desired_goal=self._state_goal,
      proprio_achieved_goal=flat_obs,)

  def get_image(self, imsize):
    # img = self.render(mode='rgb_array', width=48, height=48)  
    img = self.get_image_plt(self.fig, self.ax, imsize=imsize, draw_state=True, draw_goal=True, draw_subgoals=True)
    return img

  def get_image_plt(self, fig, ax, vals=None, extent=None,
          imsize=84, draw_state=True, draw_goal=False, draw_subgoals=False,
          state=None, goal=None, subgoals=None):
    marker_factor = self.marker_factor
    # fig.canvas.restore_region(self.bg)
    hand_pos = self.get_endeff_pos()
    puck_pos = self.get_obj_pos()
    self.plt_state_hand.center = hand_pos[0], hand_pos[1]
    self.plt_state_puck.center = puck_pos[0], puck_pos[1]
    # self.plt_goal_hand.center = self._state_goal[0], self._state_goal[1]
    # self.plt_goal_puck.center = self._state_goal[-2], self._state_goal[-1]
    img = self.plt_to_numpy(fig)

    heatmap_h = np.expand_dims((img[:, :, 1] == 255).astype(float), axis=-1)
    heatmap_p = np.expand_dims((img[:, :, 2] == 255).astype(float), axis=-1)
    hand_height = heatmap_h * hand_pos[2] * 255
    puck_height = heatmap_p * puck_pos[2] * 255
    img = np.concatenate([img, hand_height, puck_height], axis=-1)
    # print(hand_pos, puck_pos)
    return img
  
  def get_obj_pos(self):
    return self.data.get_geom_xpos('objGeom')

  def plt_to_numpy(self, fig):
    fig.canvas.draw()
    data = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    return data
 

def load_sawyer_drawer():
  gym_env = SawyerDrawer()
  gym_env = ImageEnv(gym_env, IMSIZE, normalize=True)
  gym_env = SawyerWrapper(gym_env)
  return gym_env

class SawyerDrawer(sawyer_xyz.SawyerDrawerOpenEnv):
  """Wrapper for the sawyer_reach task."""

  def __init__(self, random_init=False):
    super(SawyerDrawer, self).__init__(random_init=random_init)
    self.observation_space = gym.spaces.Box(
        low=np.full(6, -np.inf),
        high=np.full(6, np.inf),
        dtype=np.float32)
    self.observation_space = Dict([
            ('observation', self.observation_space),
            ('desired_goal', self.observation_space),
            ('achieved_goal', self.observation_space),
            ('state_observation', self.observation_space),
            ('state_desired_goal', self.observation_space),
            ('state_achieved_goal', self.observation_space),
            ('proprio_observation', self.observation_space),
            ('proprio_desired_goal', self.observation_space),
            ('proprio_achieved_goal', self.observation_space),
        ])

    # hand_low=(-0.5, 0.40, 0.05)
    # hand_high=(0.5, 1, 0.5)
    # obj_low=(-0.1, 0.6, 0.02)
    # obj_high=(0.1, 0.7, 0.02)

    hand_low=np.array([-0.5, 0.40])
    hand_high=np.array([0.5, 1])
    obj_low=np.array([-0.5, 0.4])
    obj_high=np.array([0.5, 1.0])
    
    # TODO: changes here
    imsize = IMSIZE
    fig, ax = plt.subplots()
    marker_factor = 1.0
    self.marker_factor = marker_factor
    x_bounds = np.array([hand_low[0] - 0.03, hand_high[0] + 0.03])
    y_bounds = np.array([hand_low[1] - 0.03, hand_high[1] + 0.03])
    self.vis_bounds = np.concatenate((x_bounds, y_bounds))
    extent = self.vis_bounds

    ax.set_ylim(extent[2:4])
    ax.set_xlim(extent[0:2])
    ax.set_ylim(ax.get_ylim()[::-1])
    ax.set_xlim(ax.get_xlim()[::-1])
    DPI = fig.get_dpi()
    fig.set_size_inches(imsize / float(DPI), imsize / float(DPI))

    ax.vlines(x=hand_low[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_low[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')
    ax.vlines(x=hand_high[0], ymin=hand_low[1], ymax=hand_high[1], linestyles='dotted', color='black')
    ax.hlines(y=hand_high[1], xmin=hand_low[0], xmax=hand_high[0], linestyles='dotted', color='black')

    ax.vlines(x=obj_low[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_low[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')
    ax.vlines(x=obj_high[0], ymin=obj_low[1], ymax=obj_high[1], linestyles='dotted', color='black')
    ax.hlines(y=obj_high[1], xmin=obj_low[0], xmax=obj_high[0], linestyles='dotted', color='black')

    self.plt_state_hand = plt.Circle((hand_low+hand_high)/2, 0.025 * marker_factor, color='green')
    ax.add_artist(self.plt_state_hand)
    self.plt_state_puck = plt.Circle((obj_low+obj_high)/2, 0.025 * marker_factor, color='blue')
    ax.add_artist(self.plt_state_puck)
    # self.plt_goal_hand = plt.Circle((hand_low+hand_high)/2, 0.03 * marker_factor, color='#00ff99')
    # ax.add_artist(self.plt_goal_hand)
    # self.plt_goal_puck = plt.Circle((obj_low+obj_high)/2, 0.03 * marker_factor, color='cyan')
    # ax.add_artist(self.plt_goal_puck)

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    fig.subplots_adjust(bottom=0)
    fig.subplots_adjust(top=1)
    fig.subplots_adjust(right=1)
    fig.subplots_adjust(left=0)
    ax.axis('off')
    # fig.canvas.draw()
    self.bg = fig.canvas.copy_from_bbox(fig.bbox)
    self.ax = ax
    self.fig = fig
    
    self._get_viewer('rgb_array')
    self.viewer.cam.azimuth = 270
    self.viewer.cam.distance = 1.5
    self.viewer.cam.lookat[2] = -0.2

  def set_to_goal(self, goal):
    state_goal = goal['state_desired_goal']
    self._set_puck_xy(state_goal[:3])
    self._set_hand_xy(self._arm_goal[:3])

  def _set_hand_xy(self, xy):
    for _ in range(10):
      self.data.set_mocap_pos('mocap', np.array([xy[0], xy[1], xy[2]])) #0.02
      self.data.set_mocap_quat('mocap', np.array([1, 0, 1, 0]))
      self.do_simulation([-1,1], self.frame_skip)

  def _set_puck_xy(self, pos):
    # qpos = self.data.qpos.flat.copy()
    # qvel = self.data.qvel.flat.copy()
    # qpos[7:10] = pos.copy()
    # qvel[7:10] = [0, 0, 0]
    # self.set_state(qpos, qvel)
    # self._set_obj_xyz_quat(pos, 0.0)
    delta = pos[1] - self.data.get_geom_xpos('handle')[1]
    self.data.qpos[9] += delta
    self.set_state(self.data.qpos, self.data.qvel)
    '''
    drawer_cover_pos = pos.copy()
    drawer_cover_pos[2] -= 0.02
    self.sim.model.body_pos[self.model.body_name2id('drawer')] = pos
    self.sim.model.body_pos[self.model.body_name2id('drawer_cover')] = drawer_cover_pos
    '''

  def compute_rewards(self, actions, obsBatch, prev_obs=None):
    #Required by HER-TD3
    assert isinstance(obsBatch, dict) == True
    obsList = obsBatch['state_observation']
    rewards = [0.0 for  action, obs in zip(actions, obsList)]
    return np.array(rewards)

  def reset(self, arm_goal_type='goal'):
    assert arm_goal_type in ['puck', 'goal']
    self._arm_goal = np.zeros(3)
    self.goal = np.zeros(3)
    self._state_goal = np.zeros(3)
    obs = super(SawyerDrawer, self).reset()
    offset = np.random.uniform(-0.2, 0)
    self._set_obj_xyz(offset)

    self.goal = obs['state_observation'][3:6]
    self.goal[1] = np.random.uniform(0.5, 0.7)
    if arm_goal_type == 'puck':
      self._arm_goal = obs['state_observation'][3:6]
    elif arm_goal_type == 'goal':
      self._arm_goal = self.goal.copy()
    else:
      raise NotImplementedError
    self._state_goal = self.goal.copy()
    return self._get_obs()

  def step(self, action):
    s, r, done, info = super(SawyerDrawer, self).step(action)
    r = 0.0
    done = False
    # print(s['state_observation'][:3], self._state_goal)
    info.update({'state_distance': np.linalg.norm(s['state_observation'][3:] - self._state_goal)})
    return s, r, done, info

  def _get_obs(self):
    e = self.get_endeff_pos()
    b = self.get_obj_pos()
    flat_obs = np.concatenate((e, b))

    return dict(
      observation=flat_obs,
      desired_goal=self._state_goal,
      achieved_goal=flat_obs,
      state_observation=flat_obs,
      state_desired_goal=self._state_goal,
      state_achieved_goal=flat_obs,
      proprio_observation=flat_obs,
      proprio_desired_goal=self._state_goal,
      proprio_achieved_goal=flat_obs,)

  def get_image(self, imsize):
    # img = self.render(mode='rgb_array', width=48, height=48)  
    img = self.get_image_plt(self.fig, self.ax, imsize=imsize, draw_state=True, draw_goal=True, draw_subgoals=True)
    return img

  def get_image_plt(self, fig, ax, vals=None, extent=None,
          imsize=84, draw_state=True, draw_goal=False, draw_subgoals=False,
          state=None, goal=None, subgoals=None):
    marker_factor = self.marker_factor
    # fig.canvas.restore_region(self.bg)
    hand_pos = self.get_endeff_pos()
    puck_pos = self.get_obj_pos()
    self.plt_state_hand.center = hand_pos[0], hand_pos[1]
    self.plt_state_puck.center = puck_pos[0], puck_pos[1]
    # self.plt_goal_hand.center = self._state_goal[0], self._state_goal[1]
    # self.plt_goal_puck.center = self._state_goal[-2], self._state_goal[-1]
    img = self.plt_to_numpy(fig)

    heatmap_h = np.expand_dims((img[:, :, 1] == 255).astype(float), axis=-1)
    heatmap_p = np.expand_dims((img[:, :, 2] == 255).astype(float), axis=-1)
    hand_height = heatmap_h * hand_pos[2] * 255
    puck_height = heatmap_p * puck_pos[2] * 255
    img = np.concatenate([img, hand_height, puck_height], axis=-1)
    # print(hand_pos, puck_pos)
    return img
  
  def get_obj_pos(self):
    return self.data.get_geom_xpos('handle')

  def plt_to_numpy(self, fig):
    fig.canvas.draw()
    data = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    return data
 
@gin.configurable
def load_sawyer_window(rotMode='fixed'):  # pylint: disable=invalid-name
  gym_env = SawyerWindow(rotMode=rotMode)
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=151,
  )
  return tf_py_environment.TFPyEnvironment(env)


def load_sawyer_faucet():
  gym_env = SawyerFaucet()
  env = suite_gym.wrap_env(
      gym_env,
      max_episode_steps=151,
  )
  return tf_py_environment.TFPyEnvironment(env)


def load(env_name):
  """Creates the training and evaluation environment.
  This method automatically detects whether we are using a subset of the
  observation for the goal and modifies the observation space to include the
  full state + partial goal.
  Args:
    env_name: (str) Name of the environment.
  Returns:
    tf_env, eval_tf_env, obs_dim: The training and evaluation environments.
  """
  if env_name == 'sawyer_reach':
    tf_env = load_sawyer_reach()
    eval_tf_env = load_sawyer_reach()
  elif env_name == 'sawyer_reachwall':
    tf_env = load_sawyer_reachwall()
    eval_tf_env = load_sawyer_reachwall()
  elif env_name == 'sawyer_push':
    tf_env = load_sawyer_push()
    eval_tf_env = load_sawyer_push()
  elif env_name == 'sawyer_pushwall':
    tf_env = load_sawyer_pushwall()
    eval_tf_env = load_sawyer_pushwall()
  elif env_name == 'sawyer_drawer':
    tf_env = load_sawyer_drawer()
    eval_tf_env = load_sawyer_drawer()
  elif env_name == 'sawyer_window':
    tf_env = load_sawyer_window()
    eval_tf_env = load_sawyer_window()
  elif env_name == 'sawyer_faucet':
    tf_env = load_sawyer_faucet()
    eval_tf_env = load_sawyer_faucet()
  elif env_name == 'point_small':
    tf_env = load_point_small()
    eval_tf_env = load_point_small()
  elif env_name == 'point_cross':
    tf_env = load_point_cross()
    eval_tf_env = load_point_cross()
  elif env_name == 'point_fourroom':
    tf_env = load_point_fourroom()
    eval_tf_env = load_point_fourroom()
  elif env_name == 'point_sixroom':
    tf_env = load_point_sixroom()
    eval_tf_env = load_point_sixroom()
  elif env_name == 'point_elevenmaze':
    tf_env = load_point_elevenmaze()
    eval_tf_env = load_point_elevenmaze()
  elif env_name == 'point_galton':
    tf_env = load_point_galton()
    eval_tf_env = load_point_galton()
  elif env_name == 'point_flytrapsmall':
    tf_env = load_point_flytrapsmall()
    eval_tf_env = load_point_flytrapsmall()
  elif env_name == 'point_flytrapbig':
    tf_env = load_point_flytrapbig()
    eval_tf_env = load_point_flytrapbig()
  elif env_name == 'point_tree':
    tf_env = load_point_tree()
    eval_tf_env = load_point_tree()
  else:
    raise NotImplementedError('Unsupported environment: %s' % env_name)

  # By default, the environment observation contains the current state and goal
  # state. By setting the obs_to_goal parameters, the use can specify that the
  # agent should only look at certain subsets of the goal state. The following
  # code modifies the environment observation to include the full state but only
  # the user-specified dimensions of the goal state.
  return tf_env


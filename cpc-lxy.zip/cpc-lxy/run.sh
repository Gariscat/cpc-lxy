python main.py --env_name point_fourroom --agent_name cpc_aug --lr 0.0001


nohup python main.py --env_name point_fourroom --agent_name cpc_aug > output1.log &

nohup python main.py --env_name point_fourroom --agent_name cpc_aug > output2.log &

nohup python main.py --env_name point_fourroom --agent_name cpc_aug > output3.log &

nohup python main.py --env_name point_fourroom --agent_name cpc_aug > output4.log &

nohup python main.py --env_name point_fourroom --agent_name cpc_aug > output5.log &


python main.py --env_name point_fourroom --agent_name cpc_aug --comment GaussianPolicy_seperate_conv

python main.py --env_name point_fourroom --agent_name cpc_aug --lr 0.0001 --entropy_reg 0

python main.py --env_name point_fourroom --agent_name cpc_aug --entropy_reg 0

python main.py --env_name point_fourroom --agent_name cpc_aug --comment GaussianPolicy_seperate_conv_validate

python main.py --env_name point_fourroom --agent_name cpc_aug --share_encoder --comment share_encoder


tensorboard --logdir=runs/2022-06-16_04-11-05_SAC_point_fourroom_Gaussian_

python main.py --env_name point_fourroom --agent_name cpc_aug --share_encoder --comment share_encoder

python main.py --env_name point_fourroom --agent_name cpc_aug --share_encoder --planning --comment test_cplanning
python main.py --env_name point_fourroom --agent_name cpc_aug --share_encoder --planning --Ng 8 --comment test_cplanning


### harder tasks
python main.py --env_name point_tree --agent_name cpc_aug --share_encoder --comment share_encoder
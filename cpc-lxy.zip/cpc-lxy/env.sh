∆export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/data/tianjun/clearning_slurm/mujoco200_linux/bin
export MUJOCO_PY_MUJOCO_PATH=/data/tianjun/clearning_slurm/mujoco200_linux/
export MUJOCO_PATH=/data/tianjun/clearning_slurm/mujoco200_linux/
export MUJOCO_PY_MJKEY_PATH=/data/tianjun/clearning_slurm/mujoco200_linux/mjkey.txt
export MJKEY_PATH=/data/tianjun/clearning_slurm/mujoco200_linux/mjkey.txt
tensorboard --logdir=runs/2022-06-16_02-02-43_SAC_point_fourroom_Gaussian_
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

LOG_SIG_MAX = 2
LOG_SIG_MIN = -10
epsilon = 1e-6
# FLATTEN_DIM = 1024
FLATTEN_DIM = 30976
# FLATTEN_DIM = 3136
# FLATTEN_DIM = 800
# FLATTEN_DIM = 3200
# FLATTEN_DIM = 11552

# Initialize Policy weights
def weights_init_(m):
    """Custom weight init for Conv2D and Linear layers."""
    if isinstance(m, nn.Linear):
        nn.init.orthogonal_(m.weight.data)
        m.bias.data.fill_(0.0)
    elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
        # delta-orthogonal init from https://arxiv.org/pdf/1806.05393.pdf
        assert m.weight.size(2) == m.weight.size(3)
        m.weight.data.fill_(0.0)
        m.bias.data.fill_(0.0)
        mid = m.weight.size(2) // 2
        gain = nn.init.calculate_gain('relu')
        nn.init.orthogonal_(m.weight.data[:, :, mid, mid], gain)

class ClassifierMLPNetwork(nn.Module):
    def __init__(self, num_inputs, num_actions, hidden_dim):
        super(QNetwork, self).__init__()

        # Q1 architecture
        self.linear1 = nn.Linear(num_inputs + num_actions, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, hidden_dim)
        self.linear4 = nn.Linear(hidden_dim, 1)

        # Q2 architecture
        self.linear5 = nn.Linear(num_inputs + num_actions, hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, hidden_dim)
        self.linear7 = nn.Linear(hidden_dim, hidden_dim)
        self.linear8 = nn.Linear(hidden_dim, 1)

        self.apply(weights_init_)

    def forward(self, state, action):
        xu = torch.cat([state, action], 1)
        
        x1 = F.elu(self.linear1(xu))
        x1 = F.elu(self.linear2(x1))
        x1 = F.elu(self.linear3(x1))
        x1 = self.linear4(x1)
        x1 = torch.sigmoid(x1)

        x2 = F.elu(self.linear5(xu))
        x2 = F.elu(self.linear6(x2))
        x2 = F.elu(self.linear7(x2))
        x2 = self.linear8(x2)
        x2 = torch.sigmoid(x2)

        return x1, x2

class ClassifierConvNetwork(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(ClassifierConvNetwork, self).__init__()

        # Q1 architecture
        self.conv1 = nn.Conv2d(in_planes, 32, kernel_size=3, stride=2, padding=0)
        self.conv2 = nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=0)
        self.conv3 = nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=0)
        # self.conv4 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0)
        self.linear1 = nn.Linear(FLATTEN_DIM + num_actions, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, 1)

        # Q2 architecture
        # self.conv4 = nn.Conv2d(in_planes, 8, kernel_size=3, stride=2, padding=0)
        # self.conv5 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        # self.conv6 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        self.linear4 = nn.Linear(FLATTEN_DIM + num_actions, hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, 1)

        self.apply(weights_init_)

    def forward(self, state, action):
        bs = state.shape[0]
        
        x = F.relu(self.conv1(state))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        # x = F.elu(self.conv4(x))
        x = x.reshape(bs, -1)
        xa = torch.cat([x, action], 1)

        x1 = F.elu(self.linear1(xa))
        x1 = F.elu(self.linear2(x1))
        x1 = self.linear3(x1)
        x1 = torch.sigmoid(x1)

        x2 = F.elu(self.linear4(xa))
        x2 = F.elu(self.linear5(x2))
        x2 = self.linear6(x2)
        x2 = torch.sigmoid(x2)

        return x1, x2

class ClassifierConvNetwork1(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(ClassifierConvNetwork1, self).__init__()

        # Q1 architecture
        self.conv1 = nn.Conv2d(in_planes, 32, kernel_size=4, stride=2, padding=0)
        self.conv2 = nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=0)
        self.conv4 = nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0)
        self.linear1 = nn.Linear(FLATTEN_DIM + num_actions, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, 1)

        # Q2 architecture
        self.conv5 = nn.Conv2d(in_planes, 32, kernel_size=4, stride=2, padding=0)
        self.conv6 = nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0)
        self.conv7 = nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=0)
        self.conv8 = nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0)
        self.linear4 = nn.Linear(FLATTEN_DIM + num_actions, hidden_dim)
        self.ln4 = nn.LayerNorm(hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.ln5 = nn.LayerNorm(hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, 1)

        self.apply(weights_init_)

    def forward(self, state, action):
        bs = state.shape[0]
        
        x = F.relu(self.conv1(state))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = F.elu(self.conv4(x))
        x = x.reshape(bs, -1)
        xa = torch.cat([x, action], 1)
        x1 = F.relu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.relu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        x1 = torch.sigmoid(x1)

        x = F.relu(self.conv5(state))
        x = F.relu(self.conv6(x))
        x = F.relu(self.conv7(x))
        x = F.elu(self.conv8(x))
        x = x.reshape(bs, -1)
        xa = torch.cat([x, action], 1) 
        x2 = F.relu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.relu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        x2 = torch.sigmoid(x2)

        return x1, x2

class CPCClassifierConvNetwork4(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(CPCClassifierConvNetwork4, self).__init__()
        self.obs_dim = int(in_planes/2)
        self.obs_hidden_dim = 64

        # Q1 architecture
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),])
        self.trunk = nn.Linear(FLATTEN_DIM, self.obs_hidden_dim)
        self._trunk = nn.Sequential(nn.LayerNorm(self.obs_hidden_dim), nn.Tanh())
        # self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear1 = nn.Linear(self.obs_hidden_dim + num_actions, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, self.obs_hidden_dim)
        self.ln3 = nn.LayerNorm(self.obs_hidden_dim)

        # self.apply(weights_init_)
        self.temp = 1.5

    def forward(self, state, action, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self._trunk(self.trunk(x)))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        x = _goal
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = self.trunk(x)
        # xg1 = self._ln3(xg1)
        xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True) 
        x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True) 
        x1 = torch.sigmoid(torch.mean(x1*xg1, dim=-1, keepdim=True))
        # x1 = torch.sum(x1*xg1, dim=-1, keepdim=True)

        '''
        # x = F.elu(self.conv5(_state))
        # x = F.elu(self.conv6(x))
        # x = F.elu(self.conv7(x))
        # x = F.elu(self.conv8(x))
        # x = x.reshape(bs, -1)
        # xa = torch.cat([x, action], 1) 
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        xa = torch.cat([x, action], 1) 
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        # x = F.elu(self._conv5(_goal))
        # x = F.elu(self._conv6(x))
        # x = F.elu(self._conv7(x))
        # x = F.elu(self._conv8(x))
        # x = x.reshape(bs, -1)
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        # xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        # x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        x2 = torch.sigmoid(torch.mean(x2*xg2, dim=-1, keepdim=True))
        # x2 = torch.sum(x2*xg2, dim=-1, keepdim=True)
        '''

        return x1, x1

    def get_state(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self._trunk(self.trunk(x)))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True)

        '''
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x)) 
        xa = torch.cat([x, action], 1)
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        '''
   
        return x1, x1

    def get_goal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _goal
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = self.trunk(x)
        # xg1 = self._ln3(xg1)
        xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
       
        '''
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        '''

        return xg1, xg1

    def get_auggoal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = self.trunk(x)
        # xg1 = self._ln3(xg1)
        xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
      
        '''
        x = _state
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        '''

        return xg1, xg1

    def get_aug_state(self, state):
        # return state
        bs = state.shape[0]
        half_bs = int(bs / 2)
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        # _aug_goal = torch.cat([_goal[1:], _goal[:1]], dim=0)
        idx = torch.randperm(_goal.shape[0])
        _aug_goal = _goal[idx]
        _aug_state = torch.cat([_state, _aug_goal], dim=1)

        return torch.cat([state[:half_bs], _aug_state[half_bs:]], axis=0)
        # return torch.cat([state, _aug_state], axis=0)

class CPCClassifierConvNetwork5(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(CPCClassifierConvNetwork5, self).__init__()
        self.obs_dim = int(in_planes/2)
        self.obs_hidden_dim = 1024

        # Q1 architecture
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),])
        self.xg_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),])
        self.trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim), nn.ELU(), nn.Linear(self.obs_hidden_dim, self.obs_hidden_dim))
        self.trunk1 = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim), nn.ELU(), nn.Linear(self.obs_hidden_dim, self.obs_hidden_dim))
        # self.trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim), nn.LayerNorm(self.obs_hidden_dim))
        # self.trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim))
        # self.trunk1 = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim))
        # self._trunk = nn.Sequential(nn.LayerNorm(self.obs_hidden_dim), nn.Tanh())
        self._trunk = nn.Sequential()
        # self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear1 = nn.Linear(self.obs_hidden_dim + num_actions, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)
        # self.ln1 = nn.BatchNorm1d(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        # self.ln2 = nn.BatchNorm1d(hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, self.obs_hidden_dim)
        self.ln3 = nn.LayerNorm(self.obs_hidden_dim)

        # self.apply(weights_init_)
        self.temp = 5

    def forward(self, state, action, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        
        x = _state
        # x = (x - 0.5) * 10
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self._trunk(self.trunk(x)))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        # x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        # x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        x = _goal
        # x = (x - 0.5) * 10
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = self.trunk1(x)
        # xg1 = self._ln3(xg1)
        # xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True) 
        # x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True) 
        x1 = torch.sigmoid(torch.mean(x1*xg1, dim=-1, keepdim=True))
        # x1 = torch.sum(x1*xg1, dim=-1, keepdim=True)

        '''
        # x = F.elu(self.conv5(_state))
        # x = F.elu(self.conv6(x))
        # x = F.elu(self.conv7(x))
        # x = F.elu(self.conv8(x))
        # x = x.reshape(bs, -1)
        # xa = torch.cat([x, action], 1) 
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        xa = torch.cat([x, action], 1) 
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        # x = F.elu(self._conv5(_goal))
        # x = F.elu(self._conv6(x))
        # x = F.elu(self._conv7(x))
        # x = F.elu(self._conv8(x))
        # x = x.reshape(bs, -1)
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        # xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        # x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        x2 = torch.sigmoid(torch.mean(x2*xg2, dim=-1, keepdim=True))
        # x2 = torch.sum(x2*xg2, dim=-1, keepdim=True)
        '''

        return x1, x1

    def get_state(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        # print('state ', torch.std(_state), torch.mean(_state))
        # print('goal ', torch.std(_goal), torch.mean(_goal))

        x = _state
        # x = (x - 0.5) * 10
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self._trunk(self.trunk(x)))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        # x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        # x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        # x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True)

        '''
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x)) 
        xa = torch.cat([x, action], 1)
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        '''
   
        return x1, x1

    def get_goal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _goal
        # x = (x - 0.5) * 10
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = self.trunk1(x)
        # xg1 = self._ln3(xg1)
        # xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
       
        '''
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        '''

        return xg1, xg1

    def get_auggoal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        # x = (x - 0.5) * 10
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = self.trunk1(x)
        # xg1 = self._ln3(xg1)
        # xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
      
        '''
        x = _state
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        '''

        return xg1, xg1

    def get_aug_state(self, state):
        # return state
        bs = state.shape[0]
        half_bs = int(bs / 2)
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        # _aug_goal = torch.cat([_goal[1:], _goal[:1]], dim=0)
        idx = torch.randperm(_goal.shape[0])
        _aug_goal = _goal[idx]
        _aug_state = torch.cat([_state, _aug_goal], dim=1)

        return torch.cat([state[:half_bs], _aug_state[half_bs:]], axis=0)
        # return torch.cat([state, _aug_state], axis=0)


class CPCClassifierConvNetwork2(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(CPCClassifierConvNetwork2, self).__init__()
        self.obs_dim = int(in_planes/2)

        # Q1 architecture
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0)])
            # nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),])
        self.xg_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0)])
            # nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),])
        self.trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, hidden_dim),
                nn.LayerNorm(hidden_dim), nn.Tanh())
        # self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear1 = nn.Linear(hidden_dim + num_actions, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, hidden_dim)
        self.ln3 = nn.LayerNorm(hidden_dim)

        self._trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, hidden_dim),
                nn.LayerNorm(hidden_dim), nn.Tanh())
        # self._trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self._linear1 = nn.Linear(hidden_dim, hidden_dim)
        self._ln1 = nn.LayerNorm(hidden_dim)
        self._linear2 = nn.Linear(hidden_dim, hidden_dim)
        self._ln2 = nn.LayerNorm(hidden_dim)
        self._linear3 = nn.Linear(hidden_dim, hidden_dim)
        self._ln3 = nn.LayerNorm(hidden_dim)

        # Q2 architecture
        self.linear4 = nn.Linear(hidden_dim + num_actions, hidden_dim)
        self.ln4 = nn.LayerNorm(hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.ln5 = nn.LayerNorm(hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, hidden_dim)
        self.ln6 = nn.LayerNorm(hidden_dim)

        self._linear4 = nn.Linear(hidden_dim, hidden_dim)
        self._ln4 = nn.LayerNorm(hidden_dim)
        self._linear5 = nn.Linear(hidden_dim, hidden_dim)
        self._ln5 = nn.LayerNorm(hidden_dim)
        self._linear6 = nn.Linear(hidden_dim, hidden_dim)
        self._ln6 = nn.LayerNorm(hidden_dim)
        # self.apply(weights_init_)
        self.temp = 5

    def forward(self, state, action, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = F.elu(self._trunk(x))
        xg1 = F.elu(self._linear1(xg1))
        xg1 = self._ln1(xg1)
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._ln2(xg1)
        xg1 = self._linear3(xg1)
        # xg1 = self._ln3(xg1)
        # xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True) 
        # x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True) 
        x1 = torch.sigmoid(torch.mean(x1*xg1, dim=-1, keepdim=True))
        # x1 = torch.sum(x1*xg1, dim=-1, keepdim=True)

        '''
        # x = F.elu(self.conv5(_state))
        # x = F.elu(self.conv6(x))
        # x = F.elu(self.conv7(x))
        # x = F.elu(self.conv8(x))
        # x = x.reshape(bs, -1)
        # xa = torch.cat([x, action], 1) 
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        xa = torch.cat([x, action], 1) 
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        # x = F.elu(self._conv5(_goal))
        # x = F.elu(self._conv6(x))
        # x = F.elu(self._conv7(x))
        # x = F.elu(self._conv8(x))
        # x = x.reshape(bs, -1)
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        # xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        # x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        x2 = torch.sigmoid(torch.mean(x2*xg2, dim=-1, keepdim=True))
        # x2 = torch.sum(x2*xg2, dim=-1, keepdim=True)
        '''

        return x1, x1

    def get_state(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True)

        '''
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x)) 
        xa = torch.cat([x, action], 1)
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        '''
   
        return x1, x1

    def get_goal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = F.elu(self._trunk(x))
        xg1 = F.elu(self._linear1(xg1))
        xg1 = self._ln1(xg1)
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._ln2(xg1)
        xg1 = self._linear3(xg1)
        # xg1 = self._ln3(xg1)
        xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
       
        '''
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        '''

        return xg1, xg1

    def get_auggoal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg1 = F.elu(self._trunk(x))
        xg1 = F.elu(self._linear1(xg1))
        xg1 = self._ln1(xg1)
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._ln2(xg1)
        xg1 = self._linear3(xg1)
        # xg1 = self._ln3(xg1)
        xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
      
        '''
        x = _state
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg2 = F.elu(self._trunk(x))
        xg2 = F.elu(self._linear4(xg2))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        '''

        return xg1, xg1

    def get_aug_state(self, state):
        # return state
        bs = state.shape[0]
        half_bs = int(bs / 2)
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        # _aug_goal = torch.cat([_goal[1:], _goal[:1]], dim=0)
        idx = torch.randperm(_goal.shape[0])
        _aug_goal = _goal[idx]
        _aug_state = torch.cat([_state, _aug_goal], dim=1)

        return torch.cat([state[:half_bs], _aug_state[half_bs:]], axis=0)
        # return torch.cat([state, _aug_state], axis=0)


class CPCClassifierConvNetwork1(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(CPCClassifierConvNetwork1, self).__init__()
        self.obs_dim = int(in_planes/2)

        # Q1 architecture
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 32, kernel_size=3, stride=2, padding=0),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0),])
            # nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0),])
        # self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.xg_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 32, kernel_size=3, stride=2, padding=0),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0),])
        self.linear1 = nn.Linear(FLATTEN_DIM + num_actions, hidden_dim)
        # self.ln1 = nn.LayerNorm(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, hidden_dim)

        self._linear1 = nn.Linear(FLATTEN_DIM, hidden_dim)
        # self._ln1 = nn.LayerNorm(hidden_dim)
        self._linear2 = nn.Linear(hidden_dim, hidden_dim)
        self._linear3 = nn.Linear(hidden_dim, hidden_dim)

        # Q2 architecture
        # self.conv5 = nn.Conv2d(int(in_planes/2), 8, kernel_size=3, stride=2, padding=0)
        # self.conv6 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        # self.conv7 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        # self.conv8 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0)
        self.linear4 = nn.Linear(FLATTEN_DIM + num_actions, hidden_dim)
        # self.ln4 = nn.LayerNorm(hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, hidden_dim)

        # self._conv5 = nn.Conv2d(int(in_planes/2), 8, kernel_size=3, stride=2, padding=0)
        # self._conv6 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        # self._conv7 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        # self._conv8 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0)
        self._linear4 = nn.Linear(FLATTEN_DIM, hidden_dim)
        # self._ln4 = nn.LayerNorm(hidden_dim)
        self._linear5 = nn.Linear(hidden_dim, hidden_dim)
        self._linear6 = nn.Linear(hidden_dim, hidden_dim)
        self.apply(weights_init_)

    def forward(self, state, action, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        
        x = _state
        for conv in self.xa_convs:
            x = F.relu(conv(x))
        x = x.reshape(bs, -1)
        # x = F.relu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        # x1 = F.tanh(self.ln1(self.linear1(xa)))
        x1 = F.elu(self.linear2(x1))
        x1 = self.linear3(x1)
        x = _goal
        for conv in self.xg_convs:
            x = F.relu(conv(x))
        xg = x.reshape(bs, -1)
        # xg = F.relu(self.trunk(x))
        xg1 = F.elu(self._linear1(xg))
        # xg1 = F.tanh(self._ln1(self._linear1(xg)))
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._linear3(xg1)
        x1 = torch.sigmoid(torch.mean(x1*xg1, dim=-1, keepdim=True))

        # x = F.elu(self.conv5(_state))
        # x = F.elu(self.conv6(x))
        # x = F.elu(self.conv7(x))
        # x = F.elu(self.conv8(x))
        # x = x.reshape(bs, -1)
        # xa = torch.cat([x, action], 1) 
        x2 = F.elu(self.linear4(xa))
        # x2 = F.tanh(self.ln4(self.linear4(xa)))
        x2 = F.elu(self.linear5(x2))
        x2 = self.linear6(x2)
        # x = F.elu(self._conv5(_goal))
        # x = F.elu(self._conv6(x))
        # x = F.elu(self._conv7(x))
        # x = F.elu(self._conv8(x))
        # x = x.reshape(bs, -1)
        xg2 = F.elu(self._linear4(xg))
        # xg2 = F.tanh(self._ln4(self._linear4(xg)))
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._linear6(xg2)
        x2 = torch.sigmoid(torch.mean(x2*xg2, dim=-1, keepdim=True))

        return x1, x2

    def get_state(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xa_convs:
            x = F.relu(conv(x))
        x = x.reshape(bs, -1)
        # x = F.relu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        # x1 = F.tanh(self.ln1(self.linear1(xa)))
        x1 = F.elu(self.linear2(x1))
        x1 = self.linear3(x1)

        x2 = F.elu(self.linear4(xa))
        # x2 = F.tanh(self.ln4(self.linear4(xa)))
        x2 = F.elu(self.linear5(x2))
        x2 = self.linear6(x2)
   
        return x1, x2

    def get_goal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _goal
        for conv in self.xg_convs:
            x = F.relu(conv(x))
        xg = x.reshape(bs, -1)
        # xg = F.relu(self.trunk(x))
        xg1 = F.elu(self._linear1(xg))
        # xg1 = F.tanh(self._ln1(self._linear1(xg)))
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._linear3(xg1)

        xg2 = F.elu(self._linear4(xg))
        # xg2 = F.tanh(self._ln4(self._linear4(xg)))
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._linear6(xg2)

        return xg1, xg2

    def get_aug_state(self, state):
        bs = state.shape[0]
        half_bs = int(bs / 2)
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        _aug_goal = torch.cat([_goal[1:], _goal[:1]], dim=0)
        _aug_state = torch.cat([_state, _aug_goal], dim=1)

        return torch.cat([state[:half_bs], _aug_state[half_bs:]], axis=0)

class CPCClassifierConvNetwork3(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(CPCClassifierConvNetwork3, self).__init__()
        self.obs_dim = int(in_planes/2)

        # Q1 architecture
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0)])
            # nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),])
        self.xg_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0)])
            # nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),])
        self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear1 = nn.Linear(hidden_dim + num_actions, hidden_dim)
        self.ln1 = nn.LayerNorm(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, hidden_dim)
        self.ln3 = nn.LayerNorm(hidden_dim)

        self._trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self._linear1 = nn.Linear(hidden_dim, hidden_dim)
        self._ln1 = nn.LayerNorm(hidden_dim)
        self._linear2 = nn.Linear(hidden_dim, hidden_dim)
        self._ln2 = nn.LayerNorm(hidden_dim)
        self._linear3 = nn.Linear(hidden_dim, hidden_dim)
        self._ln3 = nn.LayerNorm(hidden_dim)

        # Q2 architecture
        self.xa_convs1 = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0),])
            # nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),])
        self.xg_convs1 = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0)])
            # nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),])
        self.trunk1 = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear4 = nn.Linear(hidden_dim + num_actions, hidden_dim)
        self.ln4 = nn.LayerNorm(hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.ln5 = nn.LayerNorm(hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, hidden_dim)
        self.ln6 = nn.LayerNorm(hidden_dim)

        self._trunk1 = nn.Linear(FLATTEN_DIM, hidden_dim)
        self._linear4 = nn.Linear(hidden_dim, hidden_dim)
        self._ln4 = nn.LayerNorm(hidden_dim)
        self._linear5 = nn.Linear(hidden_dim, hidden_dim)
        self._ln5 = nn.LayerNorm(hidden_dim)
        self._linear6 = nn.Linear(hidden_dim, hidden_dim)
        self._ln6 = nn.LayerNorm(hidden_dim)
        self.apply(weights_init_)
        self.temp = 2

    def forward(self, state, action, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        if detach:
            x = x.detach()
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.elu(self._trunk(x))
        if detach:
            xg = xg.detach()
        xg1 = F.elu(self._linear1(xg))
        xg1 = self._ln1(xg1)
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._ln2(xg1)
        xg1 = self._linear3(xg1)
        # xg1 = self._ln3(xg1)
        # xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True) 
        # x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True) 
        x1 = torch.sigmoid(torch.mean(x1*xg1, dim=-1, keepdim=True))

        # x = F.elu(self.conv5(_state))
        # x = F.elu(self.conv6(x))
        # x = F.elu(self.conv7(x))
        # x = F.elu(self.conv8(x))
        # x = x.reshape(bs, -1)
        # xa = torch.cat([x, action], 1) 
        x = _state
        for conv in self.xa_convs1:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk1(x))
        if detach:
            x = x.detach()
        xa = torch.cat([x, action], 1) 
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        # x = F.elu(self._conv5(_goal))
        # x = F.elu(self._conv6(x))
        # x = F.elu(self._conv7(x))
        # x = F.elu(self._conv8(x))
        # x = x.reshape(bs, -1)
        x = _goal
        for conv in self.xg_convs1:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.elu(self._trunk1(x))
        if detach:
            xg = xg.detach()
        xg2 = F.elu(self._linear4(xg))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        # xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)
        # x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
        x2 = torch.sigmoid(torch.mean(x2*xg2, dim=-1, keepdim=True))

        return x1, x2

    def get_state(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.elu(self.linear1(xa))
        x1 = self.ln1(x1)
        x1 = F.elu(self.linear2(x1))
        x1 = self.ln2(x1)
        x1 = self.linear3(x1)
        # x1 = self.ln3(x1)
        # x1 = self.temp * x1/torch.norm(x1, dim=-1, keepdim=True)

        x = _state
        for conv in self.xa_convs1:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk1(x)) 
        xa = torch.cat([x, action], 1)
        x2 = F.elu(self.linear4(xa))
        x2 = self.ln4(x2)
        x2 = F.elu(self.linear5(x2))
        x2 = self.ln5(x2)
        x2 = self.linear6(x2)
        # x2 = self.ln6(x2)
        # x2 = self.temp * x2/torch.norm(x2, dim=-1, keepdim=True)
   
        return x1, x2

    def get_goal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.elu(self._trunk(x))
        xg1 = F.elu(self._linear1(xg))
        xg1 = self._ln1(xg1)
        xg1 = F.elu(self._linear2(xg1))
        xg1 = self._ln2(xg1)
        xg1 = self._linear3(xg1)
        # xg1 = self._ln3(xg1)
        # xg1 = self.temp * xg1/torch.norm(xg1, dim=-1, keepdim=True)
      
        x = _goal
        for conv in self.xg_convs1:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.elu(self._trunk1(x))
        xg2 = F.elu(self._linear4(xg))
        xg2 = self._ln4(xg2)
        xg2 = F.elu(self._linear5(xg2))
        xg2 = self._ln5(xg2)
        xg2 = self._linear6(xg2)
        # xg2 = self._ln6(xg2)
        # xg2 = self.temp * xg2/torch.norm(xg2, dim=-1, keepdim=True)

        return xg1, xg2

    def get_aug_state(self, state):
        # return state
        bs = state.shape[0]
        half_bs = int(bs / 2)
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        # _aug_goal = torch.cat([_goal[1:], _goal[:1]], dim=0)
        idx = torch.randperm(_goal.shape[0])
        _aug_goal = _goal[idx]
        _aug_state = torch.cat([_state, _aug_goal], dim=1)

        return torch.cat([state[:half_bs], _aug_state[half_bs:]], axis=0)
        # return torch.cat([state, _aug_state], axis=0)



class CPCClassifierConvNetwork(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(CPCClassifierConvNetwork, self).__init__()
        self.obs_dim = int(in_planes/2)

        # Q1 architecture
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 32, kernel_size=3, stride=2, padding=0),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=0),
            nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=0),])
            # nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0),])
        self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear1 = nn.Linear(hidden_dim + num_actions, hidden_dim)
        # self.ln1 = nn.LayerNorm(hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, hidden_dim)

        self._linear1 = nn.Linear(hidden_dim, hidden_dim)
        # self._ln1 = nn.LayerNorm(hidden_dim)
        self._linear2 = nn.Linear(hidden_dim, hidden_dim)
        self._linear3 = nn.Linear(hidden_dim, hidden_dim)

        # Q2 architecture
        # self.conv5 = nn.Conv2d(int(in_planes/2), 8, kernel_size=3, stride=2, padding=0)
        # self.conv6 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        # self.conv7 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        # self.conv8 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0)
        self.linear4 = nn.Linear(hidden_dim + num_actions, hidden_dim)
        # self.ln4 = nn.LayerNorm(hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, hidden_dim)

        # self._conv5 = nn.Conv2d(int(in_planes/2), 8, kernel_size=3, stride=2, padding=0)
        # self._conv6 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        # self._conv7 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        # self._conv8 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0)
        self._linear4 = nn.Linear(hidden_dim, hidden_dim)
        # self._ln4 = nn.LayerNorm(hidden_dim)
        self._linear5 = nn.Linear(hidden_dim, hidden_dim)
        self._linear6 = nn.Linear(hidden_dim, hidden_dim)
        self.apply(weights_init_)

    def forward(self, state, action, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        
        x = _state
        for conv in self.xa_convs:
            x = F.relu(conv(x))
        x = x.reshape(bs, -1)
        x = F.relu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.relu(self.linear1(xa))
        # x1 = F.tanh(self.ln1(self.linear1(xa)))
        x1 = F.relu(self.linear2(x1))
        x1 = self.linear3(x1)
        x = _goal
        for conv in self.xa_convs:
            x = F.relu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.relu(self.trunk(x))
        xg1 = F.relu(self._linear1(xg))
        # xg1 = F.tanh(self._ln1(self._linear1(xg)))
        xg1 = F.relu(self._linear2(xg1))
        xg1 = self._linear3(xg1)
        x1 = torch.sigmoid(torch.mean(x1*xg1, dim=-1, keepdim=True))

        # x = F.elu(self.conv5(_state))
        # x = F.elu(self.conv6(x))
        # x = F.elu(self.conv7(x))
        # x = F.elu(self.conv8(x))
        # x = x.reshape(bs, -1)
        # xa = torch.cat([x, action], 1) 
        x2 = F.relu(self.linear4(xa))
        # x2 = F.tanh(self.ln4(self.linear4(xa)))
        x2 = F.relu(self.linear5(x2))
        x2 = self.linear6(x2)
        # x = F.elu(self._conv5(_goal))
        # x = F.elu(self._conv6(x))
        # x = F.elu(self._conv7(x))
        # x = F.elu(self._conv8(x))
        # x = x.reshape(bs, -1)
        xg2 = F.relu(self._linear4(xg))
        # xg2 = F.tanh(self._ln4(self._linear4(xg)))
        xg2 = F.relu(self._linear5(xg2))
        xg2 = self._linear6(xg2)
        x2 = torch.sigmoid(torch.mean(x2*xg2, dim=-1, keepdim=True))

        return x1, x2

    def get_state(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _state
        for conv in self.xa_convs:
            x = F.relu(conv(x))
        x = x.reshape(bs, -1)
        x = F.relu(self.trunk(x))
        xa = torch.cat([x, action], 1)
        x1 = F.relu(self.linear1(xa))
        # x1 = F.tanh(self.ln1(self.linear1(xa)))
        x1 = F.relu(self.linear2(x1))
        x1 = self.linear3(x1)

        x2 = F.relu(self.linear4(xa))
        # x2 = F.tanh(self.ln4(self.linear4(xa)))
        x2 = F.relu(self.linear5(x2))
        x2 = self.linear6(x2)
   
        return x1, x2

    def get_goal(self, state, action):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]

        x = _goal
        for conv in self.xa_convs:
            x = F.relu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.relu(self.trunk(x))
        xg1 = F.relu(self._linear1(xg))
        # xg1 = F.tanh(self._ln1(self._linear1(xg)))
        xg1 = F.relu(self._linear2(xg1))
        xg1 = self._linear3(xg1)

        xg2 = F.relu(self._linear4(xg))
        # xg2 = F.tanh(self._ln4(self._linear4(xg)))
        xg2 = F.relu(self._linear5(xg2))
        xg2 = self._linear6(xg2)

        return xg1, xg2

    def get_aug_state(self, state):
        bs = state.shape[0]
        half_bs = int(bs / 2)
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
        _aug_goal = torch.cat([_goal[1:], _goal[:1]], dim=0)
        _aug_state = torch.cat([_state, _aug_goal], dim=1)

        return torch.cat([state[:half_bs], _aug_state[half_bs:]], axis=0)

class QConvNetwork(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim):
        super(QConvNetwork, self).__init__()

        # Q1 architecture
        self.conv1 = nn.Conv2d(in_planes, 8, kernel_size=3, stride=2, padding=0)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        self.conv3 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        self.conv4 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0)
        self.linear1 = nn.Linear(FLATTEN_DIM+num_actions, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3 = nn.Linear(hidden_dim, 1)

        # Q2 architecture
        # self.conv4 = nn.Conv2d(in_planes, 8, kernel_size=3, stride=2, padding=0)
        # self.conv5 = nn.Conv2d(8, 16, kernel_size=3, stride=2, padding=0)
        # self.conv6 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=0)
        self.linear4 = nn.Linear(FLATTEN_DIM+num_actions, hidden_dim)
        self.linear5 = nn.Linear(hidden_dim, hidden_dim)
        self.linear6 = nn.Linear(hidden_dim, 1)

        self.apply(weights_init_)

    def forward(self, state, action):
        
        bs = state.shape[0]

        x = F.elu(self.conv1(state))
        x = F.elu(self.conv2(x))
        x = F.elu(self.conv3(x))
        x = F.elu(self.conv4(x))
        x = x.reshape(bs, -1)
        xa = torch.cat([x, action], 1) 
        
        x1 = F.elu(self.linear1(xa))
        x1 = F.elu(self.linear2(x1))
        x1 = self.linear3(x1)
      
        x2 = F.elu(self.linear4(xa))
        x2 = F.elu(self.linear5(x2))
        x2 = self.linear6(x2)

        return x1, x2

class GaussianConvPolicy1(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim, action_space=None):
        super(GaussianConvPolicy1, self).__init__()
        self.obs_dim = int(in_planes/2)
        
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),])
            # nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0),])
        self.trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim),
                nn.LayerNorm(self.obs_hidden_dim), nn.Tanh()) 
        self.xg_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes/2), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),])
        self.trunk = nn.Linear(FLATTEN_DIM, hidden_dim)
        self.linear1 = nn.Linear(hidden_dim*2, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)

        self.mean_linear = nn.Linear(hidden_dim, num_actions)
        self.log_std_linear = nn.Linear(hidden_dim, num_actions)

        self.apply(weights_init_)

        # action rescaling
        if action_space is None:
            self.action_scale = torch.tensor(1.)
            self.action_bias = torch.tensor(0.)
        else:
            self.action_scale = torch.FloatTensor(
                (action_space.high - action_space.low) / 2.)
            self.action_bias = torch.FloatTensor(
                (action_space.high + action_space.low) / 2.)

    def forward(self, state, detach=False):
        bs = state.shape[0]
        _goal = state[:, self.obs_dim:, :, :]
        _state = state[:, :self.obs_dim, :, :]
 
        x = _state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        x = F.elu(self.trunk(x))
        if detach:
            x = x.detach()
        xa = x
        x = _goal
        for conv in self.xg_convs:
            x = F.elu(conv(x))
        x = x.reshape(bs, -1)
        xg = F.elu(self._trunk(x))
        xa = torch.cat([xa, xg], axis=-1)
        if detach:
            xa = xa.detach()
        xa = F.elu(self.linear1(xa))
        # xa = F.tanh(self.ln1(self.linear1(xa)))
        xa = F.elu(self.linear2(xa))
        mean = self.mean_linear(xa)
        log_std = self.log_std_linear(xa)
        log_std = torch.clamp(log_std, min=LOG_SIG_MIN, max=LOG_SIG_MAX)
        return mean, log_std

    def sample(self, state, detach=False):
        mean, log_std = self.forward(state, detach=detach)
        std = log_std.exp()
        normal = Normal(mean, std)
        x_t = normal.rsample()  # for reparameterization trick (mean + std * N(0,1))
        y_t = torch.tanh(x_t)
        action = y_t * self.action_scale + self.action_bias
        log_prob = normal.log_prob(x_t)
        # Enforcing Action Bound
        log_prob -= torch.log(self.action_scale * (1 - y_t.pow(2)) + epsilon)
        log_prob = log_prob.sum(1, keepdim=True)
        mean = torch.tanh(mean) * self.action_scale + self.action_bias
        return action, log_prob, mean

    def act(self, state, detach=False):
        mean, log_std = self.forward(state, detach=detach)
        std = log_std.exp()
        normal = Normal(mean, std)
        x_t = normal.rsample()  # for reparameterization trick (mean + std * N(0,1))
        y_t = torch.tanh(x_t)
        action = y_t * self.action_scale + self.action_bias
        mean = torch.tanh(mean) * self.action_scale + self.action_bias
        return action, mean

    def to(self, device):
        self.action_scale = self.action_scale.to(device)
        self.action_bias = self.action_bias.to(device)
        return super(GaussianConvPolicy1, self).to(device)


class GaussianConvPolicy(nn.Module):
    def __init__(self, in_planes, num_actions, hidden_dim, action_space=None):
        super(GaussianConvPolicy, self).__init__()
        self.obs_hidden_dim = 64
        
        self.xa_convs = nn.ModuleList([
            nn.Conv2d(int(in_planes), 64, kernel_size=4, stride=2, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),
            nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0),])
            # nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=0),])
        self.trunk = nn.Sequential(nn.Linear(FLATTEN_DIM, self.obs_hidden_dim),
                nn.LayerNorm(self.obs_hidden_dim), nn.Tanh())
        self.linear1 = nn.Linear(self.obs_hidden_dim, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)

        self.mean_linear = nn.Linear(hidden_dim, num_actions)
        self.log_std_linear = nn.Linear(hidden_dim, num_actions)

        self.apply(weights_init_)

        # action rescaling
        if action_space is None:
            self.action_scale = torch.tensor(1.)
            self.action_bias = torch.tensor(0.)
        else:
            self.action_scale = torch.FloatTensor(
                (action_space.high - action_space.low) / 2.)
            self.action_bias = torch.FloatTensor(
                (action_space.high + action_space.low) / 2.)

    def forward(self, state, detach=False):
        bs = state.shape[0]
        x = state
        for conv in self.xa_convs:
            x = F.elu(conv(x))
        xa = x.reshape(bs, -1)
        xa = self.trunk(xa)
        xa = F.elu(self.linear1(xa))
        xa = F.elu(self.linear2(xa))
        mean = self.mean_linear(xa)
        log_std = self.log_std_linear(xa)
        log_std = torch.clamp(log_std, min=LOG_SIG_MIN, max=LOG_SIG_MAX)
        return mean, log_std

    def sample(self, state):
        mean, log_std = self.forward(state)
        std = log_std.exp()
        normal = Normal(mean, std)
        x_t = normal.rsample()  # for reparameterization trick (mean + std * N(0,1))
        y_t = torch.tanh(x_t)
        action = y_t * self.action_scale + self.action_bias
        log_prob = normal.log_prob(x_t)
        # Enforcing Action Bound
        log_prob -= torch.log(self.action_scale * (1 - y_t.pow(2)) + epsilon)
        log_prob = log_prob.sum(1, keepdim=True)
        mean = torch.tanh(mean) * self.action_scale + self.action_bias
        return action, log_prob, mean

    def act(self, state):
        mean, log_std = self.forward(state)
        std = log_std.exp()
        normal = Normal(mean, std)
        x_t = normal.rsample()  # for reparameterization trick (mean + std * N(0,1))
        y_t = torch.tanh(x_t)
        action = y_t * self.action_scale + self.action_bias
        mean = torch.tanh(mean) * self.action_scale + self.action_bias
        return action, mean

    def to(self, device):
        self.action_scale = self.action_scale.to(device)
        self.action_bias = self.action_bias.to(device)
        return super(GaussianConvPolicy, self).to(device)


class DeterministicPolicy(nn.Module):
    def __init__(self, num_inputs, num_actions, hidden_dim, action_space=None):
        super(DeterministicPolicy, self).__init__()
        self.linear1 = nn.Linear(num_inputs, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)

        self.mean = nn.Linear(hidden_dim, num_actions)
        self.noise = torch.Tensor(num_actions)

        self.apply(weights_init_)

        # action rescaling
        if action_space is None:
            self.action_scale = 1.
            self.action_bias = 0.
        else:
            self.action_scale = torch.FloatTensor(
                (action_space.high - action_space.low) / 2.)
            self.action_bias = torch.FloatTensor(
                (action_space.high + action_space.low) / 2.)

    def forward(self, state):
        x = F.relu(self.linear1(state))
        x = F.relu(self.linear2(x))
        mean = torch.tanh(self.mean(x)) * self.action_scale + self.action_bias
        return mean

    def sample(self, state):
        mean = self.forward(state)
        noise = self.noise.normal_(0., std=0.1)
        noise = noise.clamp(-0.25, 0.25)
        action = mean + noise
        return action, torch.tensor(0.), mean

    def to(self, device):
        self.action_scale = self.action_scale.to(device)
        self.action_bias = self.action_bias.to(device)
        self.noise = self.noise.to(device)
        return super(DeterministicPolicy, self).to(device)

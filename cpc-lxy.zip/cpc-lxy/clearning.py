import os
import torch
import torch.nn.functional as F
from torch.optim import Adam
from utils import soft_update, hard_update, tie_weights
from model import GaussianConvPolicy, GaussianConvPolicy1, ClassifierConvNetwork, ClassifierConvNetwork1, CPCClassifierConvNetwork, CPCClassifierConvNetwork1, CPCClassifierConvNetwork2, CPCClassifierConvNetwork3, CPCClassifierConvNetwork4, CPCClassifierConvNetwork5
import kornia
import numpy as np
from maze_env import *

class RunningMeanStd(object):
    # https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance#Parallel_algorithm
    def __init__(self, epsilon=10, shape=()):
        self.mean = np.zeros(shape, 'float64')
        self.var = np.ones(shape, 'float64')
        self.count = epsilon

    def update(self, x):
        # x = np.expand_dims(x, axis=0)
        batch_mean = np.mean(x, axis=0, keepdims=True)
        batch_var = np.var(x, axis=0, keepdims=True)
        batch_count = x.shape[0]
        self.update_from_moments(batch_mean, batch_var, batch_count)

    def update_from_moments(self, batch_mean, batch_var, batch_count):
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count

        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * (self.count)
        m_b = batch_var * (batch_count)
        M2 = m_a + m_b + np.square(delta) * self.count * batch_count / (self.count + batch_count)
        new_var = M2 / (self.count + batch_count)

        new_count = batch_count + self.count

        self.mean = new_mean
        self.var = new_var
        self.count = new_count

class CLearning(object):
    def __init__(self, in_planes, action_space, args):

        self.gamma = args.gamma
        self.tau = args.tau
        self.alpha = args.alpha
        self.relabel_next_prob = args.relabel_next_prob
        self.relabel_future_prob = args.relabel_future_prob
        self.relabel_next_num = int(self.relabel_next_prob * args.batch_size)
        self.relabel_future_num = int(self.relabel_future_prob * args.batch_size)
        self.relabel_random_num = args.batch_size - (self.relabel_next_num + self.relabel_future_num)
        self.crop = kornia.augmentation.RandomCrop((60, 60))
        self.center_crop = kornia.augmentation.CenterCrop((60, 60))
        self.obs_dim = int(in_planes/2)

        self.policy_type = args.policy
        self.target_update_interval = args.target_update_interval
        self.automatic_entropy_tuning = args.automatic_entropy_tuning

        self.device = torch.device("cuda" if args.cuda else "cpu")

        # self.critic = ClassifierConvNetwork1(in_planes, action_space.shape[0], args.hidden_size).to(device=self.device)
        self.critic = CPCClassifierConvNetwork5(in_planes, action_space.shape[0], 256).to(device=self.device)
        self.critic_optim = Adam(self.critic.parameters(), lr=args.lr)

        # self.critic_target = ClassifierConvNetwork1(in_planes, action_space.shape[0], args.hidden_size).to(self.device)
        self.critic_target = CPCClassifierConvNetwork5(in_planes, action_space.shape[0], 256).to(self.device)
        hard_update(self.critic_target, self.critic)

        if self.policy_type == "Gaussian":
            # self.policy = GaussianConvPolicy(in_planes, action_space.shape[0], args.hidden_size, action_space).to(self.device)
            self.policy = GaussianConvPolicy(in_planes, action_space.shape[0], 256, action_space).to(self.device)
            self.policy_optim = Adam(self.policy.parameters(), lr=args.lr)
        else:
            assert False
            self.alpha = 0
            self.automatic_entropy_tuning = False
            self.policy = DeterministicPolicy(in_planes, action_space.shape[0], args.hidden_size, action_space).to(self.device)
            self.policy_optim = Adam(self.policy.parameters(), lr=args.lr)
      
        self.obs_rms = RunningMeanStd(shape=(1, int(in_planes/2), 64, 64))
        self.normalize = False
        self.eps = 1e-3
        '''
        for i in range(3):
            tie_weights(src=self.critic.xa_convs[i], trg=self.policy.xa_convs[i])
            tie_weights(src=self.critic.xg_convs[i], trg=self.policy.xg_convs[i])
        '''

    def norm_state(self, state):
        state = torch.FloatTensor(state).to(self.device).unsqueeze(0)
        if self.normalize:
            mean = torch.FloatTensor(self.obs_rms.mean).to(self.device)
            var = torch.FloatTensor(self.obs_rms.var).to(self.device)
            _state = (state[:, :self.obs_dim] - mean) / torch.sqrt(var)
            _goal = (state[:, self.obs_dim:] - mean) / torch.sqrt(var)
            state = torch.clip(torch.concat([_state, _goal], dim=1), -50, 50)

        return state

    def select_action(self, state, evaluate=False):
        state = torch.FloatTensor(state).to(self.device).unsqueeze(0)
        if self.normalize:
            mean = torch.FloatTensor(self.obs_rms.mean).to(self.device)
            var = torch.FloatTensor(self.obs_rms.var).to(self.device)
            _state = (state[:, :self.obs_dim] - mean) / torch.sqrt(var)
            _goal = (state[:, self.obs_dim:] - mean) / torch.sqrt(var)
            state = torch.clip(torch.concat([_state, _goal], dim=1), -50, 50)
        # state = torch.concat([self.center_crop(state[:, :self.obs_dim]), self.center_crop(state[:, self.obs_dim:])], dim=1)
        with torch.no_grad():
            if evaluate is False:
                action, _ = self.policy.act(state)
            else:
                _, action = self.policy.act(state)
        return action.detach().cpu().numpy()[0]

    def update_parameters(self, memory, batch_size, updates, sample, index):
        # if updates % 2 != 0:
        #     return 0.0, 0.0, 0.0, 0.0, 0.0
        # Sample a batch from memory
        state_batch, action_batch, reward_batch, next_state_batch, mask_batch, goal_batch = memory.sample(batch_size=batch_size)
        # self.obs_rms.update(state_batch[:, :self.obs_dim].cpu().numpy())
        if self.normalize:
            mean = torch.FloatTensor(self.obs_rms.mean).to(self.device)
            var = torch.FloatTensor(self.obs_rms.var).to(self.device)
            _state = (state_batch[:, :self.obs_dim] - mean) / torch.sqrt(var)
            _goal = (state_batch[:, self.obs_dim:] - mean) / torch.sqrt(var)
            norm_state_batch = torch.clip(torch.concat([_state, _goal], dim=1), -50, 50)
            _goal = (goal_batch - mean) / torch.sqrt(var)
            norm_goal_batch = torch.clip(torch.concat([_state, _goal], dim=1), -50, 50)
        else:
            norm_state_batch = state_batch
            _state = state_batch[:, :self.obs_dim]
            _goal = goal_batch
            norm_goal_batch = torch.concat([_state, _goal], dim=1)
        # state_batch = torch.concat([self.crop(state_batch[:, :self.obs_dim]), self.crop(state_batch[:, self.obs_dim:])], dim=1)
        # next_state_batch = torch.concat([self.crop(next_state_batch[:, :self.obs_dim]), self.crop(next_state_batch[:, self.obs_dim:])], dim=1)
        # norm_state_batch = torch.concat([self.crop(norm_state_batch[:, :self.obs_dim]), self.crop(norm_state_batch[:, self.obs_dim:])], dim=1)
        # next_state_batch = torch.concat([self.crop(next_state_batch[:, :self.obs_dim]), self.crop(next_state_batch[:, self.obs_dim:])], dim=1)
        # state_batch, action_batch, reward_batch, next_state_batch, mask_batch = sample
        '''
        state_batch, action_batch, reward_batch, next_state_batch, mask_batch = sample
        state_batch = state_batch[index*batch_size:(index+1)*batch_size]
        next_state_batch = next_state_batch[index*batch_size:(index+1)*batch_size]
        action_batch = action_batch[index*batch_size:(index+1)*batch_size]
        reward_batch = reward_batch[index*batch_size:(index+1)*batch_size]
        mask_batch = mask_batch[index*batch_size:(index+1)*batch_size]
        '''

        if updates % 1 == 0:
            with torch.no_grad():
                # next_state_action, next_state_log_pi, _ = self.policy.sample(next_state_batch)
                next_state_action, _ = self.policy.act(next_state_batch)
                qf1_next_target, qf2_next_target = self.critic_target(next_state_batch, next_state_action)
                min_qf_next_target = torch.min(qf1_next_target, qf2_next_target)
                w = min_qf_next_target.detach() / (1 - min_qf_next_target.detach())
                # next_q_value = reward_batch + mask_batch * self.gamma * (min_qf_next_target)
                w = torch.clip(w, 0, 100)
                weights = torch.concat([torch.ones(self.relabel_next_num, 1).to(self.device) * (1 - self.gamma),
                        torch.ones(self.relabel_future_num, 1).to(self.device),
                        (1 + self.gamma * w)[-self.relabel_random_num:]], dim=0)
                next_q_value = self.gamma * w / (1 + self.gamma * w)
                next_q_value = reward_batch + (1 - reward_batch) * next_q_value
                next_q_value = torch.concat([torch.ones(self.relabel_next_num+self.relabel_future_num, 1).to(self.device),
                    next_q_value[-self.relabel_random_num:]], dim=0)

            qf1, qf2 = self.critic(state_batch, action_batch)  # Two Q-functions to mitigate positive bias in the policy improvement step
            qf1_loss = torch.nn.BCELoss(reduction='none')(qf1, next_q_value.detach())  # JQ = 𝔼(st,at)~D[0.5(Q1(st,at) - r(st,at) - γ(𝔼st+1~p[V(st+1)]))^2]
            qf2_loss = torch.nn.BCELoss(reduction='none')(qf2, next_q_value.detach())  # JQ = 𝔼(st,at)~D[0.5(Q1(st,at) - r(st,at) - γ(𝔼st+1~p[V(st+1)]))^2]
            
            qf1_loss = qf1_loss_pos.mean()
            qf2_loss = qf2_loss_pos.mean()
            qf_loss = 0.5 * (qf1_loss + qf2_loss)

            self.critic_optim.zero_grad()
            qf_loss.backward()
            self.critic_optim.step()
        else:
            qf1_loss = torch.zeros([1]).mean()
            qf2_loss = torch.zeros([1]).mean()

        if updates % 2 == 0:
            pi, log_pi, _ = self.policy.sample(state_batch)
            # with torch.no_grad():
            qf1_pi, qf2_pi = self.critic(state_batch, pi)
            min_qf_pi = torch.min(qf1_pi, qf2_pi) 

            # policy_loss = 1e-4 * log_pi.mean() - min_qf_pi.mean() # Jπ = 𝔼st∼D,εt∼N[α * logπ(f(εt;st)|st) − Q(st,f(εt;st))]
            # policy_loss = 1e-3 * log_pi.mean() - min_qf_pi.mean() # Jπ = 𝔼st∼D,εt∼N[α * logπ(f(εt;st)|st) − Q(st,f(εt;st))]
            # policy_loss = 3e-2 * log_pi.mean() - min_qf_pi.mean() # Jπ = 𝔼st∼D,εt∼N[α * logπ(f(εt;st)|st) − Q(st,f(εt;st))]
            # policy_loss = 1e-1 * log_pi.mean() - min_qf_pi.mean() # Jπ = 𝔼st∼D,εt∼N[α * logπ(f(εt;st)|st) − Q(st,f(εt;st))]
            policy_loss = 3e-4 * log_pi.mean() - min_qf_pi.mean() # Jπ = 𝔼st∼D,εt∼N[α * logπ(f(εt;st)|st) − Q(st,f(εt;st))]

            self.policy_optim.zero_grad()
            policy_loss.backward()
            self.policy_optim.step()
        else:
            policy_loss = torch.zeros([1]).mean()

        # if updates % self.target_update_interval == 0:
        #     soft_update(self.critic_target, self.critic, self.tau)
            
        '''
        hard_update(self.critic_target.xa_convs, self.critic.xa_convs)
        hard_update(self.critic_target.xg_convs, self.critic.xg_convs)
        hard_update(self.critic_target.trunk, self.critic.trunk)
        hard_update(self.critic_target._trunk, self.critic._trunk)
        '''

        alpha_loss = torch.zeros([1]).mean()
        alpha_tlogs = torch.zeros([1]).mean()
        return (0.5 * qf1_loss).item(), (0.5 * qf2_loss).item(), policy_loss.item(), alpha_loss.item(), alpha_tlogs.item()

    # Save model parameters
    def save_checkpoint(self, env_name, suffix="", ckpt_path=None):
        if not os.path.exists('checkpoints/'):
            os.makedirs('checkpoints/')
        if ckpt_path is None:
            ckpt_path = "checkpoints/sac_checkpoint_{}_{}".format(env_name, suffix)
        print('Saving models to {}'.format(ckpt_path))
        torch.save({'policy_state_dict': self.policy.state_dict(),
                    'critic_state_dict': self.critic.state_dict(),
                    'critic_target_state_dict': self.critic_target.state_dict(),
                    'critic_optimizer_state_dict': self.critic_optim.state_dict(),
                    'policy_optimizer_state_dict': self.policy_optim.state_dict()}, ckpt_path)

    # Load model parameters
    def load_checkpoint(self, ckpt_path, evaluate=False):
        print('Loading models from {}'.format(ckpt_path))
        if ckpt_path is not None:
            checkpoint = torch.load(ckpt_path)
            self.policy.load_state_dict(checkpoint['policy_state_dict'])
            self.critic.load_state_dict(checkpoint['critic_state_dict'])
            self.critic_target.load_state_dict(checkpoint['critic_target_state_dict'])
            self.critic_optim.load_state_dict(checkpoint['critic_optimizer_state_dict'])
            self.policy_optim.load_state_dict(checkpoint['policy_optimizer_state_dict'])

            if evaluate:
                self.policy.eval()
                self.critic.eval()
                self.critic_target.eval()
            else:
                self.policy.train()
                self.critic.train()
                self.critic_target.train()

